CREATE VIEW [dbo].[vw_T_config]
AS
SELECT     dbo.T_Device.IP, dbo.T_CONFIG.*
FROM         dbo.T_CONFIG CROSS JOIN
                      dbo.T_Device
go

