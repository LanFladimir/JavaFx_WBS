create view [dbo].[v_t_device]
as
SELECT     autoid, devicetype, deviceid, devicename, ip, display_ui, 
wardid, roomid, alias, positionx, positiony, creator, createtime, editor, modifytime,
 modified, readstatus, 
 readtime, 
 CASE devicetype WHEN '1' THEN '主机' WHEN '2' THEN '护士分机' WHEN '3' THEN '门口屏' WHEN '4' THEN '走廊屏幕' WHEN '5' THEN '电子一览表' WHEN '6' THEN '综合显示屏' END AS devicetypetext,
     (SELECT     wardname
       FROM          dbo.t_ward AS w
       WHERE      (wardid = c.wardid)) AS wardname,
     (SELECT     roomname
       FROM          dbo.t_sickroom AS r
       WHERE      (roomid = c.roomid)) AS roomname,
     (SELECT     username
       FROM          dbo.t_sys_users AS u
       WHERE      (userid = c.creator)) AS createname,
     (SELECT     username
       FROM          dbo.t_sys_users AS u
       WHERE      (userid = c.editor)) AS editname
FROM         dbo.t_device AS c
go

