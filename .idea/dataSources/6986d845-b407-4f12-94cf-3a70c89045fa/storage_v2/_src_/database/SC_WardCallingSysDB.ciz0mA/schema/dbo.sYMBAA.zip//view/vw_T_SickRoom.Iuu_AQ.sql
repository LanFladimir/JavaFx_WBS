--病房视图
create view [dbo].[vw_T_SickRoom]
as 
select r.AUTOID,r.WARDID,w.WARDNAME, ROOMID, ROOMNAME, DEVICEID, r.ALIAS, 
	r.CREATETIME, r.CREATOR,a.USERNAME CREATORNAME, r.modifytime, r.EDITOR,b.USERNAME EDITORNAME
from T_SickRoom r 
left outer join t_ward w on r.wardid=w.wardid
left outer join t_sys_users a on r.CREATOR=a.userid
left outer join t_sys_users b on r.EDITOR=b.userid
go

