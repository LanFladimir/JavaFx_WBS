CREATE procedure [dbo].[GetPatientItemByIP]          
--GetPatientItemByIP '192.168.2.90'  
--@ip 设备ip         
 @ip varchar(20)                
as              
SELECT a.in_hospital_no AS zyh ,a.itemcode,b.itemtype,case itemtype when 1 then itemname+REPLICATE(' ',8-len(b.itemname)) else b.itemname end itemname FROM t_inp_item a LEFT JOIN 
t_inp_itemtype b ON a.itemcode = b.autoid
WHERE a.in_hospital_no IN 
(SELECT in_hospital_no  FROM t_inhospital  WHERE wardid IN (SELECT wardid FROM t_device WHERE ip=@ip)
AND t_inhospital.status=1)

go

