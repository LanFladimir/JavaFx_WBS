CREATE VIEW [dbo].[v_inp_out_patient]
AS
SELECT     wardid, in_hospital_no, patient_name
FROM         dbo.t_inhospital AS a
WHERE     (in_hospital_no NOT IN
                          (SELECT     in_hospital_no
                            FROM          dbo.t_inp_out AS b
                            WHERE      (status = '1') AND (a.in_hospital_no = in_hospital_no))) AND (status = '1')
go

