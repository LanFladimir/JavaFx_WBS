create view [dbo].[V_MenuInfo]
as
SELECT     dbo.t_sys_r_f_menu.roleid, dbo.t_sys_menu.menuid, dbo.t_sys_menu.pmenuid, dbo.t_sys_menu.menuname, dbo.t_sys_menu.filename, dbo.t_sys_menu.ico, dbo.t_sys_menu.displayorder, 
                      dbo.t_sys_menu.isuse AS MenuIsUse, dbo.t_sys_func.funcid, dbo.t_sys_func.funcname, dbo.t_sys_func.isuse AS funcisuse
FROM         dbo.t_sys_func INNER JOIN
                      dbo.t_sys_r_f_menu ON dbo.t_sys_func.funcid = dbo.t_sys_r_f_menu.funcid RIGHT OUTER JOIN
                      dbo.t_sys_menu ON dbo.t_sys_r_f_menu.menuid = dbo.t_sys_menu.menuid
WHERE     (dbo.t_sys_menu.isuse = '1') AND (dbo.t_sys_func.isuse = '1')
go

