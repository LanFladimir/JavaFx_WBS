CREATE procedure [dbo].[getWardServiceGroupReport_1]                 
 @wardid varchar(20),                  
 @begindate varchar(10),          
 @enddate varchar(10)          
-- getWardServiceGroupReport_1 1,'2016-01-01','2016-01-31'          
--@wardid 病区代码          
--@begindate 报表开始日期            
--@enddate 报表结束日期          
as             
 declare @great int          
 declare @better int          
 declare @good int          
 declare @bad int          
 set @great=60          
 set @better=120          
 set @good=180          
 set @bad=300               
 declare @cnt int                         
 declare @deviceid varchar(10)                  
 declare @devicename varchar(100)             
 declare @devicealias varchar(100)                 
 --建立临时表.                  
 create table #listreport                 
 (序号 int IDENTITY (1,1),          
  呼叫时间 varchar(20),          
  呼叫者  varchar(30),          
  病区    varchar(100),          
  病房   varchar(100),          
  床位     varchar(100),            
  处理时间 varchar(20),          
  是否增援 varchar(2),  --是否          
  响应时间 varchar(20), --响应时间（秒)  1分钟10秒          
  响应情况 varchar(4), --优良合格差          
  紧急呼叫 varchar(4)  --是否紧急呼叫            
 )                  
                     
                     
 select @cnt=count(*) from t_ward where wardid=@wardid           
 if @cnt>0                   
 begin                  
   --查询出此ip对应的病区代码，病房代码，设备代码，设备名称.          
    insert into #listreport(呼叫时间,呼叫者,病区,          
  病房,床位,处理时间,          
  是否增援,响应时间,响应情况,          
    紧急呼叫)                      
    select convert(varchar(20),l.dialtime,120),isnull(h.patient_name,l.in_hospital_no),w.wardname,          
    r.roomname,b.bedname,convert(varchar(20),l.starttime,120),             
    case when l.status=2 then '是' else '否' end,          
    convert(varchar,floor(datediff(s,l.dialtime,l.starttime) /60))+'分'+          
    convert(varchar,datediff(s,l.dialtime,l.starttime)-floor(datediff(s,l.dialtime,l.starttime) /60)*60)+'秒',          
    case when l.status=0 then '差'            
         when datediff(s,l.dialtime,l.starttime)<=@great then '优'          
         when datediff(s,l.dialtime,l.starttime)<=@better then '良'           
         when datediff(s,l.dialtime,l.starttime)<=@good then '合格'               
         else '差'              
    end,          
    case when l.type=2 then  '紧急' else '普通' end              
    from t_calllog l          
    left outer join  t_ward w on l.wardid=w.wardid          
    left outer join  t_sickroom r on l.wardid=r.wardid and l.roomid=r.roomid          
    left outer join t_sickbed b on l.roomid=b.roomid  and l.bedid=b.bedid-- l.wardid=b.wardid and        
   left outer join t_inhospital h on l.in_hospital_no=h.in_hospital_no          
   where w.wardid=@wardid              
   and dialtime between @begindate and dateadd(d,1,@enddate)        
   order by dialtime           
   --更新病人信息                  
   --更新医生信息，护士信息                  
   --返回门口屏对应的信息              
   select IDENTITY(int,1,1) as  序号,响应情况,count(*)  数量,'        ' 比例 into #t from #listreport  group by 响应情况           
   select @cnt=count(*) from #listreport          
   update #t set 比例=convert(varchar,floor(数量*100/@cnt))+'%'          
         
   create table #rep
   (xh varchar(10),xyqk varchar(4) ,sl int ,bl varchar(10))
   insert into #rep(xh,xyqk,sl,bl)
   values('1','优',0,'0%')
   insert into #rep(xh,xyqk,sl,bl)
   values('2','良',0,'0%')
   insert into #rep(xh,xyqk,sl,bl)
   values('3','合格',0,'0%')
   insert into #rep(xh,xyqk,sl,bl)
   values('4','差',0,'0%')
   insert into #rep(xh,xyqk,sl,bl)
   values('合 计','',0,'100%')      
   
   update #rep set sl=a.sl,bl=a.bl 
   from #rep r,(select convert(varchar,序号) xh,响应情况 xyqk,数量 sl,比例 bl from #t) a
   where r.xyqk=a.xyqk 

   update #rep set sl=@cnt where xh='合 计'

   select * from #rep
   
   
   --select convert(varchar,序号) xh,响应情况 xyqk,数量 sl,比例 bl from #t          
   --union          
   --select '合 计' xh,'' xyqk,@cnt sl ,'100%' bl      
   drop table #rep
   drop table #t          
               
 end                  
 else                  
 begin                  
   --返回空表                  
   select '0' xh,' ' xyqk,0 sl,'' bl       where 1<>1          
 end                  
--删除临时表                  
 drop table #listreport
go

