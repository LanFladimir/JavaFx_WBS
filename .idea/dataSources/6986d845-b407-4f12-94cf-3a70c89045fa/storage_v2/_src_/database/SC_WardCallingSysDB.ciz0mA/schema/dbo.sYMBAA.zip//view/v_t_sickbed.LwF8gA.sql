CREATE VIEW [dbo].[v_t_sickbed]
AS
SELECT     c.autoid, c.bedid, c.bedname, c.roomid, c.status, c.createtime, c.creator, c.editor, c.alias, c.modifytime,
                          (SELECT     roomname
                            FROM          dbo.t_sickroom AS r
                            WHERE      (roomid = c.roomid)) AS roomname, CASE c.status WHEN '1' THEN '使用' WHEN '0' THEN '空闲' WHEN '-1' THEN '损坏/维修' END AS statustext,
                          (SELECT     username
                            FROM          dbo.t_sys_users AS u
                            WHERE      (userid = c.creator)) AS createname,
                          (SELECT     username
                            FROM          dbo.t_sys_users AS u
                            WHERE      (userid = c.editor)) AS editname, t.autoid AS terminalautoid, t.devicename AS terminalname, t.alias AS terminalalias, 
                      CASE t .status WHEN '0' THEN '正常' WHEN '1' THEN '损坏/维修' END AS terminalstatustext, c.hisbedid, t.terminalid
FROM         dbo.t_sickbed AS c LEFT OUTER JOIN
                          (SELECT     autoid, terminalid, devicename, alias, roomid, bedid, terminaltype, status, callstatus, calltime, sentstatus, creator, createtime, editor, modifytime, modified, readstatus, readtime
                            FROM          dbo.t_terminal
                            WHERE      (terminaltype = '1')) AS t ON c.bedid = t.bedid
go

