
CREATE procedure [dbo].[up_getwardpatitentlist]
  @wardid varchar(100)  
as 
  create table #patitentlist
  (in_hospital_no  varchar(10),
   patient_name varchar(30),
   patient_age varchar(10),
   patient_sex varchar(2),
   patient_diagnosis varchar(100),
   in_hospital_time varchar(10),
   wardid varchar(10),
   wardname varchar(30),
   bedid varchar(10),
   bedname varchar(30),
   patient_grade varchar(20),
   patient_gradetext varchar(20),
   patient_food varchar(100),
   patient_allergy varchar(200),
   seriously varchar(200),
   partition varchar(20),
   status varchar(10)
   )

  if (@wardid='' ) --没有找到对应的wardid
  begin
    select * from #patitentlist
    drop table #patitentlist
	return
  end    
    --将病区，病房，病床，病人信息插入到 临时表
    insert into #patitentlist(wardid,wardname,bedid,bedname)
    select r.wardid,r.wardname,b.bedid,b.bedname from v_t_sickbed b 
    left join v_t_sickroom r on r.roomid=b.roomid 
    where r.wardid in (@wardid)
    order by b.autoid,b.bedid   
    --更新病人的住院号、姓名、年龄、性别、诊断、入院时间、护理等级代码、护理等级、隔离方式
    update #patitentlist set in_hospital_no=d.in_hospital_no,
    patient_name=d.patient_name,
    patient_age=d.patient_age,
    patient_sex=d.patient_sextext,
    patient_diagnosis=d.patient_diagnosis,
    in_hospital_time=CONVERT(varchar(10),d.in_hospital_time,120),
    patient_grade=d.itemcode,
    patient_gradetext=d.patient_gradetext,
    partition= d.partitiontext
    from #patitentlist p, v_t_inhospital d where p.wardid=d.wardid and p.wardname=d.wardname
    and p.bedid=d.bedid and p.bedname=d.bedname
    and d.wardid in (@wardid) and d.status='1'
    --更新病人的入/出院标志
    update #patitentlist set status='1'--新入
    where in_hospital_no in 
    (select in_hospital_no from t_inhospital where datediff(hour,in_hospital_time,getdate())<24)
    --更新病人的入/出院标志
    update #patitentlist set status='2'--今出
    where in_hospital_no in (select in_hospital_no from t_inp_out where outtime=CONVERT(varchar(10),getdate(),120)
    and status='1')
    --更新病人的入/出院标志
    update #patitentlist set status='3'--明出.png
    where in_hospital_no in (select in_hospital_no from t_inp_out where outtime=CONVERT(varchar(10),getdate()+1,120)
    and status='1') 
    --更新patient_food
	update #patitentlist set patient_food=d.patient_allergyLst
	 from #patitentlist p ,(select in_hospital_no, 
	 stuff((select ','+cast(b.itemname as varchar) from v_t_inp_item b
	 where b.itemtype='3' and a.in_hospital_no=b.in_hospital_no
	 group by in_hospital_no,itemname,itemcode,itemtype for xml path('')),1,1,'')   as patient_allergyLst
	 from v_t_inp_item a where a.itemtype='3' group by in_hospital_no,itemname,itemcode,itemtype) d
	 where p.in_hospital_no=d.in_hospital_no
 
	 --更新patient_allergy
	 update #patitentlist set patient_allergy=d.patient_allergyLst
	 from #patitentlist p ,(select in_hospital_no, 
	 stuff((select ','+cast(b.itemname as varchar) from v_t_inp_item b
	 where b.itemtype='1' and a.in_hospital_no=b.in_hospital_no
	 group by in_hospital_no,itemname,itemcode,itemtype for xml path('')),1,1,'')   as patient_allergyLst
	 from v_t_inp_item a where a.itemtype='1' group by in_hospital_no,itemname,itemcode,itemtype) d
	 where p.in_hospital_no=d.in_hospital_no 
	--更新seriously
	 update #patitentlist set seriously=d.patient_allergyLst
	 from #patitentlist p ,(select in_hospital_no, 
	 stuff((select ','+cast(b.itemname as varchar) from v_t_inp_item b
	 where b.itemtype='4' and a.in_hospital_no=b.in_hospital_no
	 group by in_hospital_no,itemname,itemcode,itemtype for xml path('')),1,1,'')   as patient_allergyLst
	 from v_t_inp_item a where a.itemtype='4' group by in_hospital_no,itemname,itemcode,itemtype) d
	 where p.in_hospital_no=d.in_hospital_no 
	 
	 select * from #patitentlist
	 drop table #patitentlist
	 return
go

