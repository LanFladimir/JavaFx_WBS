CREATE PROCEDURE [dbo].[UP_WCS_DATA]
	@TableName [varchar](25),
	@Column [varchar](25),
	@ViewField [varchar](4000) = '*',
	@sqlWhere [varchar](1500) = '',
	@OrderColumns [varchar](4000),
	@OrderType [varchar](4) = 'asc',
	@PageSize [int] = 10,
	@CurrentPage [int] = 1,
	@TotalPage int output,
    @TotalCounts int output, 
	@userid varchar(10) 
WITH EXECUTE AS CALLER
AS
begin
	--获取病区信息
	declare @flag char(1)
	select @flag=flag from t_sys_users where userid=@userid
	if @flag<>'0'  begin
		SELECT @sqlWhere=@sqlWhere+ ' and wardid in ('''+stuff((SELECT ''',''' + wardid  FROM t_user_ward AS t
		WHERE t.userid = A.userid AND userid=@userid FOR xml path('')), 1, 3, '')+''')'
		FROM  t_user_ward A WHERE userid=@userid
		GROUP BY USERID
	end
	--调用存储过程
	exec UP_PAGINATION @tablename,@column,@viewfield,@sqlWhere,@OrderColumns,@OrderType,@pagesize,@currentpage,@TotalPage output,@totalcounts output
end
go

