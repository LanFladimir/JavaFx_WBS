CREATE VIEW [dbo].[v_t_guide]
AS
SELECT     autoid, guide_type, CASE guide_type WHEN '1' THEN '饮食宣教' WHEN '2' THEN '疾病宣教' WHEN '3' THEN '服药宣教' END AS guide_typetext, guide_name, editor, modifytime, createtime, 
                      creator, isdefault, CASE isdefault WHEN '0' THEN '否' WHEN '1' THEN '是' END AS isdefaulttext, keywords, guide_content,
                          (SELECT     username
                            FROM          dbo.t_sys_users AS u
                            WHERE      (userid = c.creator)) AS createname,
                          (SELECT     username
                            FROM          dbo.t_sys_users AS u
                            WHERE      (userid = c.editor)) AS editname
FROM         dbo.t_guide AS c
go

