
-------------------------------------
/*
存储过程名称：sp_过敏隔离信息
功能：根据ip参数获取本病区的过敏隔离信息.
返回说明:
找到对应ip的电子一览表设置,返回这个病区的所有过敏隔离信息,
返回内容包括：
  (名称 ,
   病床名称
   )
示例：
exec sp_过敏隔离信息 '192.168.2.95'
select * from t_device where devicetype=5
select @wardid=wardid from t_device where ip=@ip and devicetype=5
*/
-------------------------------------
CREATE procedure  [dbo].[sp_过敏隔离信息]
  @ip varchar(20)
as 
  declare @wardid varchar(10) 
  select @wardid=wardid from t_device where ip=@ip and devicetype=5
  set @wardid=ISNULL(@wardid,'')
  create table #过敏隔离信息
  (名称 varchar(30),
   病床名称 varchar(200)
   )
  create table #电子一览表
  (病区代码 varchar(10),
   病区名称 varchar(30),
   病房代码 varchar(10),
   病房名称 varchar(30),  
   病床代码 varchar(10),
   病床名称 varchar(30)        
   )
   
  if (@wardid='' ) --没有找到对应的病区代码
  begin
    select '' 名称,'' 病床名称 where 1=2
    drop table #电子一览表
	return
  end   
   --将空气隔离插入到 临时表
   insert into #电子一览表(	
   病区代码 ,
   病区名称 ,
   病房代码 ,
   病房名称 ,   
   病床代码 ,
   病床名称          
	)
   select a.wardid,a.wardname,b.roomid,b.roomname,c.bedid,c.bedname
   from t_ward a ,t_sickroom b,t_sickbed c,t_inhospital d,t_inp_item e
   where a.wardid=@wardid 
		and b.wardid=a.wardid
		and c.roomid=b.roomid
		and d.bedid=c.bedid			
		and d.in_hospital_no=e.in_hospital_no	
		and e.itemcode in (select autoid from t_inp_itemtype where itemname='空气隔离')		
   declare @bednames varchar(500)
   set @bednames=''
   declare @mc varchar(30)
  declare cursor1 cursor for         
  select 病床名称 from #电子一览表 order by 病床名称           
  open cursor1                        
  fetch next from cursor1 into @mc
  while @@fetch_status=0           
  begin
    set @bednames = @bednames+ @mc+' '
  fetch next from cursor1 into @mc
  end 
  close cursor1                  
  deallocate cursor1 
  insert into #过敏隔离信息   
   select '空气隔离' 名称,@bednames 病床名称
   truncate table #电子一览表
   
   --将飞沫隔离到 临时表
   insert into #电子一览表(	
   病区代码 ,
   病区名称 ,
   病房代码 ,
   病房名称 ,   
   病床代码 ,
   病床名称          
	)
   select a.wardid,a.wardname,b.roomid,b.roomname,c.bedid,c.bedname
   from t_ward a ,t_sickroom b,t_sickbed c,t_inhospital d,t_inp_item e
   where a.wardid=@wardid 
		and b.wardid=a.wardid
		and c.roomid=b.roomid
		and d.bedid=c.bedid			
		and d.in_hospital_no=e.in_hospital_no	
		and e.itemcode in (select autoid from t_inp_itemtype where itemname='飞沫隔离')	
   set @bednames=''
  declare cursor1 cursor for         
  select 病床名称 from #电子一览表 order by 病床名称           
  open cursor1                        
  fetch next from cursor1 into @mc
  while @@fetch_status=0           
  begin
    set @bednames = @bednames+ @mc+' '
  fetch next from cursor1 into @mc
  end 
  close cursor1                  
  deallocate cursor1 
  insert into #过敏隔离信息   
   select '飞沫隔离' 名称,@bednames 病床名称
   truncate table #电子一览表   
    
   --将接触隔离插入到 临时表
   insert into #电子一览表(	
   病区代码 ,
   病区名称 ,
   病房代码 ,
   病房名称 ,   
   病床代码 ,
   病床名称          
	)
   select a.wardid,a.wardname,b.roomid,b.roomname,c.bedid,c.bedname
   from t_ward a ,t_sickroom b,t_sickbed c,t_inhospital d,t_inp_item e
   where a.wardid=@wardid 
		and b.wardid=a.wardid
		and c.roomid=b.roomid
		and d.bedid=c.bedid			
		and d.in_hospital_no=e.in_hospital_no	
		and e.itemcode in (select autoid from t_inp_itemtype where itemname='接触隔离')	
  set @bednames=''
  declare cursor1 cursor for         
  select 病床名称 from #电子一览表 order by 病床名称           
  open cursor1                        
  fetch next from cursor1 into @mc
  while @@fetch_status=0           
  begin
    set @bednames = @bednames+ @mc+' '
  fetch next from cursor1 into @mc
  end 
  close cursor1                  
  deallocate cursor1 
  insert into #过敏隔离信息   
   select '接触隔离' 名称,@bednames 病床名称
   truncate table #电子一览表       
    
   --将青霉素过敏插入到 临时表
   insert into #电子一览表(	
   病区代码 ,
   病区名称 ,
   病房代码 ,
   病房名称 ,   
   病床代码 ,
   病床名称          
	)
   select a.wardid,a.wardname,b.roomid,b.roomname,c.bedid,c.bedname
   from t_ward a ,t_sickroom b,t_sickbed c,t_inhospital d,t_inp_item e
   where a.wardid=@wardid 
		and b.wardid=a.wardid
		and c.roomid=b.roomid
		and d.bedid=c.bedid			
		and d.in_hospital_no=e.in_hospital_no	
		and e.itemcode in (select autoid from t_inp_itemtype where itemnote='青霉素')	
  set @bednames=''
  declare cursor1 cursor for         
  select 病床名称 from #电子一览表 order by 病床名称           
  open cursor1                        
  fetch next from cursor1 into @mc
  while @@fetch_status=0           
  begin
    set @bednames = @bednames+ @mc+' '
  fetch next from cursor1 into @mc
  end 
  close cursor1                  
  deallocate cursor1 
  insert into #过敏隔离信息   
   select '青霉素' 名称,@bednames 病床名称
   truncate table #电子一览表   
    
   --将头孢类插入到 临时表
   insert into #电子一览表(	
   病区代码 ,
   病区名称 ,
   病房代码 ,
   病房名称 ,   
   病床代码 ,
   病床名称          
	)
   select a.wardid,a.wardname,b.roomid,b.roomname,c.bedid,c.bedname
   from t_ward a ,t_sickroom b,t_sickbed c,t_inhospital d,t_inp_item e
   where a.wardid=@wardid 
		and b.wardid=a.wardid
		and c.roomid=b.roomid
		and d.bedid=c.bedid			
		and d.in_hospital_no=e.in_hospital_no	
		and e.itemcode in (select autoid from t_inp_itemtype where itemnote='头孢')	
  set @bednames=''
  declare cursor1 cursor for         
  select 病床名称 from #电子一览表 order by 病床名称           
  open cursor1                        
  fetch next from cursor1 into @mc
  while @@fetch_status=0           
  begin
    set @bednames = @bednames+ @mc+' '
  fetch next from cursor1 into @mc
  end 
  close cursor1                  
  deallocate cursor1 
  insert into #过敏隔离信息   
   select '头孢类' 名称,@bednames 病床名称
   truncate table #电子一览表   
    
   --将黄胺素插入到 临时表
   insert into #电子一览表(	
   病区代码 ,
   病区名称 ,
   病房代码 ,
   病房名称 ,   
   病床代码 ,
   病床名称          
	)
   select a.wardid,a.wardname,b.roomid,b.roomname,c.bedid,c.bedname
   from t_ward a ,t_sickroom b,t_sickbed c,t_inhospital d,t_inp_item e
   where a.wardid=@wardid 
		and b.wardid=a.wardid
		and c.roomid=b.roomid
		and d.bedid=c.bedid			
		and d.in_hospital_no=e.in_hospital_no	
		and e.itemcode in (select autoid from t_inp_itemtype where itemnote='磺胺')	
  set @bednames=''
  declare cursor1 cursor for         
  select 病床名称 from #电子一览表 order by 病床名称           
  open cursor1                        
  fetch next from cursor1 into @mc
  while @@fetch_status=0           
  begin
    set @bednames = @bednames+ @mc+' '
  fetch next from cursor1 into @mc
  end 
  close cursor1                  
  deallocate cursor1 
  insert into #过敏隔离信息   
   select '黄胺类' 名称,@bednames 病床名称
   truncate table #电子一览表   

   --将黄胺素插入到 临时表
   insert into #电子一览表(	
   病区代码 ,
   病区名称 ,
   病房代码 ,
   病房名称 ,   
   病床代码 ,
   病床名称          
	)
   select a.wardid,a.wardname,b.roomid,b.roomname,c.bedid,c.bedname
   from t_ward a ,t_sickroom b,t_sickbed c,t_inhospital d,t_inp_item e
   where a.wardid=@wardid 
		and b.wardid=a.wardid
		and c.roomid=b.roomid
		and d.bedid=c.bedid			
		and d.in_hospital_no=e.in_hospital_no	
		and e.itemcode in (select autoid from t_inp_itemtype where itemnote='其它')	
  set @bednames=''
  declare cursor1 cursor for         
  select 病床名称 from #电子一览表 order by 病床名称           
  open cursor1                        
  fetch next from cursor1 into @mc
  while @@fetch_status=0           
  begin
    set @bednames = @bednames+ @mc+' '
  fetch next from cursor1 into @mc
  end 
  close cursor1                  
  deallocate cursor1 
  insert into #过敏隔离信息   
   select '其它类1' 名称,@bednames 病床名称
   truncate table #电子一览表          
   --将黄胺素插入到 临时表
   insert into #电子一览表(	
   病区代码 ,
   病区名称 ,
   病房代码 ,
   病房名称 ,   
   病床代码 ,
   病床名称          
	)
   select a.wardid,a.wardname,b.roomid,b.roomname,c.bedid,c.bedname
   from t_ward a ,t_sickroom b,t_sickbed c,t_inhospital d,t_inp_item e
   where a.wardid=@wardid 
		and b.wardid=a.wardid
		and c.roomid=b.roomid
		and d.bedid=c.bedid			
		and d.in_hospital_no=e.in_hospital_no	
		and e.itemcode in (select autoid from t_inp_itemtype where itemname='其它类2')	
  set @bednames=''
  declare cursor1 cursor for         
  select 病床名称 from #电子一览表 order by 病床名称           
  open cursor1                        
  fetch next from cursor1 into @mc
  while @@fetch_status=0           
  begin
    set @bednames = @bednames+ @mc+' '
  fetch next from cursor1 into @mc
  end 
  close cursor1                  
  deallocate cursor1 
  insert into #过敏隔离信息   
   select '其它类2' 名称,@bednames 病床名称
   truncate table #电子一览表  

   --将黄胺素插入到 临时表
   insert into #电子一览表(	
   病区代码 ,
   病区名称 ,
   病房代码 ,
   病房名称 ,   
   病床代码 ,
   病床名称          
	)
   select a.wardid,a.wardname,b.roomid,b.roomname,c.bedid,c.bedname
   from t_ward a ,t_sickroom b,t_sickbed c,t_inhospital d,t_inp_item e
   where a.wardid=@wardid 
		and b.wardid=a.wardid
		and c.roomid=b.roomid
		and d.bedid=c.bedid			
		and d.in_hospital_no=e.in_hospital_no	
		and e.itemcode in (select autoid from t_inp_itemtype where itemname='其它类3')	
  set @bednames=''
  declare cursor1 cursor for         
  select 病床名称 from #电子一览表 order by 病床名称           
  open cursor1                        
  fetch next from cursor1 into @mc
  while @@fetch_status=0           
  begin
    set @bednames = @bednames+ @mc+' '
  fetch next from cursor1 into @mc
  end 
  close cursor1                  
  deallocate cursor1 
  insert into #过敏隔离信息   
   select '其它类3' 名称,@bednames 病床名称
   truncate table #电子一览表   
   --将黄胺素插入到 临时表
   insert into #电子一览表(	
   病区代码 ,
   病区名称 ,
   病房代码 ,
   病房名称 ,   
   病床代码 ,
   病床名称          
	)
   select a.wardid,a.wardname,b.roomid,b.roomname,c.bedid,c.bedname
   from t_ward a ,t_sickroom b,t_sickbed c,t_inhospital d,t_inp_item e
   where a.wardid=@wardid 
		and b.wardid=a.wardid
		and c.roomid=b.roomid
		and d.bedid=c.bedid			
		and d.in_hospital_no=e.in_hospital_no	
		and e.itemcode in (select autoid from t_inp_itemtype where itemname='其它类4')	
  set @bednames=''
  declare cursor1 cursor for         
  select 病床名称 from #电子一览表 order by 病床名称           
  open cursor1                        
  fetch next from cursor1 into @mc
  while @@fetch_status=0           
  begin
    set @bednames = @bednames+ @mc+' '
  fetch next from cursor1 into @mc
  end 
  close cursor1                  
  deallocate cursor1 
  insert into #过敏隔离信息   
   select '其它类4' 名称,@bednames 病床名称
   truncate table #电子一览表    
   --将床边隔离插入到 临时表
   insert into #电子一览表(	
   病区代码 ,
   病区名称 ,
   病房代码 ,
   病房名称 ,   
   病床代码 ,
   病床名称          
	)
   select a.wardid,a.wardname,b.roomid,b.roomname,c.bedid,c.bedname
   from t_ward a ,t_sickroom b,t_sickbed c,t_inhospital d,t_inp_item e
   where a.wardid=@wardid 
		and b.wardid=a.wardid
		and c.roomid=b.roomid
		and d.bedid=c.bedid			
		and d.in_hospital_no=e.in_hospital_no	
		and e.itemcode in (select autoid from t_inp_itemtype where itemname='床边隔离')	
  set @bednames=''
  declare cursor1 cursor for         
  select 病床名称 from #电子一览表 order by 病床名称           
  open cursor1                        
  fetch next from cursor1 into @mc
  while @@fetch_status=0           
  begin
    set @bednames = @bednames+ @mc+' '
  fetch next from cursor1 into @mc
  end 
  close cursor1                  
  deallocate cursor1 
  insert into #过敏隔离信息   
   select '床边隔离' 名称,@bednames 病床名称
   truncate table #电子一览表            
   drop table #电子一览表
  
   select * from #过敏隔离信息 
   drop table #过敏隔离信息
   return



go

