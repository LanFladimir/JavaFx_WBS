CREATE VIEW [dbo].[vw_Room_Device_terminal]
AS
SELECT     dbo.T_SickRoom.AUTOID, dbo.T_SickRoom.ROOMID, dbo.T_SickRoom.ROOMNAME, dbo.T_SickRoom.DEVICEID, dbo.T_SickRoom.ALIAS, 
                      dbo.T_SickRoom.CREATETIME, dbo.T_SickRoom.CREATOR, dbo.T_SickRoom.modifytime, dbo.T_SickRoom.EDITOR, dbo.T_SickRoom.WARDID, 
                      dbo.T_Device.DEVICETYPE, dbo.T_Device.DEVICENAME, dbo.T_Device.IP, dbo.T_Device.DISPLAY_UI, dbo.T_Terminal.TERMINALID, 
                      dbo.T_Terminal.DEVICENAME AS terminalname, dbo.T_Terminal.BEDID, dbo.T_Terminal.TERMINALTYPE
FROM         dbo.T_SickRoom INNER JOIN
                      dbo.T_Device ON dbo.T_SickRoom.DEVICEID = dbo.T_Device.DEVICEID INNER JOIN
                      dbo.T_Terminal ON dbo.T_SickRoom.ROOMID = dbo.T_Terminal.ROOMID
go

