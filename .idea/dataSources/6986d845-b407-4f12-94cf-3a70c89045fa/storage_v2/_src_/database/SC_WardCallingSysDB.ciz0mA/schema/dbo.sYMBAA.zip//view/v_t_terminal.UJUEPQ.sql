CREATE VIEW [dbo].[v_t_terminal]
AS
SELECT     autoid, terminalid, devicename, alias, roomid, bedid, terminaltype, CASE c.terminaltype WHEN '1' THEN '床头' WHEN '2' THEN '卫浴' END AS terminaltypetext, status, 
                      CASE c.STATUS WHEN '0' THEN '正常' WHEN '1' THEN '损坏/维修' END AS statustext, callstatus, createtime, modifytime, 
                      CASE c.callstatus WHEN '0' THEN '空闲' WHEN '1' THEN '正在呼叫' END AS callstatustext,
                          (SELECT     roomname
                            FROM          dbo.t_sickroom AS r
                            WHERE      (roomid = c.roomid)) AS roomname,
                          (SELECT     bedname
                            FROM          dbo.t_sickbed AS b
                            WHERE      (c.bedid = bedid)) AS bedname,
                          (SELECT     username
                            FROM          dbo.t_sys_users AS u
                            WHERE      (userid = c.creator)) AS createname,
                          (SELECT     username
                            FROM          dbo.t_sys_users AS u
                            WHERE      (userid = c.editor)) AS editname, CASE c.sentstatus WHEN '0' THEN '未提交' WHEN '1' THEN '已提交' END AS sentstatustext, modified, readstatus, readtime,
                          (SELECT     wardid
                            FROM          dbo.t_sickroom AS r
                            WHERE      (c.roomid = roomid)) AS wardid
FROM         dbo.t_terminal AS c
go

