
-------------------------------------
/*
存储过程名称：sp_医护人员
功能：根据ip参数获取本病区的医护人员信息.
返回说明:
找到对应ip的电子一览表设置,返回这个病区的所有医护人员,
返回内容包括：
  (病区代码 varchar(10),
   病区名称 varchar(30),
   责任医生代码1 varchar(30),
   责任医生姓名1 varchar(30),
   责任医生代码2 varchar(30),
   责任医生姓名2 varchar(30),
   责任医生代码3 varchar(30),
   责任医生姓名3 varchar(30),  
   责任护士代码1 varchar(30),
   责任护士姓名1 varchar(30),
   责任护士代码2 varchar(30),
   责任护士姓名2 varchar(30),
   责任护士代码3 varchar(30),
   责任护士姓名3 varchar(30),
   责任护士代码4 varchar(30),
   责任护士姓名4 varchar(30),
   值班医生代码1 varchar(30),  
   值班医生姓名1 varchar(30),  
   值班医生代码2 varchar(30),  
   值班医生姓名2 varchar(30),  
   值班医生代码3 varchar(30),  
   值班医生姓名3 varchar(30)  
   )
示例：
exec sp_医护人员 '192.168.2.95'

*/
-------------------------------------
CREATE procedure  [dbo].[sp_医护人员]
  @ip varchar(20)
as 
  declare @wardid varchar(10)  
  select @wardid=wardid from t_device where ip=@ip and devicetype=5
  set @wardid=ISNULL(@wardid,'')

  create table #电子一览表
  (病区代码 varchar(10),
   病区名称 varchar(30),
   责任医生代码1 varchar(30),
   责任医生姓名1 varchar(30),
   责任医生电话1 varchar(30),
   责任医生代码2 varchar(30),
   责任医生姓名2 varchar(30),
   责任医生电话2 varchar(30),
   责任医生代码3 varchar(30),
   责任医生姓名3 varchar(30),
   责任医生电话3 varchar(30),  
   责任护士代码1 varchar(30),
   责任护士姓名1 varchar(30),
   责任护士电话1 varchar(30),
   责任护士代码2 varchar(30),
   责任护士姓名2 varchar(30),
   责任护士电话2 varchar(30),
   责任护士代码3 varchar(30),
   责任护士姓名3 varchar(30),
   责任护士电话3 varchar(30),
   责任护士代码4 varchar(30),
   责任护士姓名4 varchar(30),
   责任护士电话4 varchar(30),
   值班医生代码1 varchar(30),  
   值班医生姓名1 varchar(30),  
   值班医生电话1 varchar(30),  
   值班医生代码2 varchar(30),  
   值班医生姓名2 varchar(30),  
   值班医生电话2 varchar(30),  
   值班医生代码3 varchar(30),  
   值班医生姓名3 varchar(30),
   值班医生电话3 varchar(30)  
   )
   
  if (@wardid='' ) --没有找到对应的病区代码
  begin
    select * from #电子一览表
    drop table #电子一览表
	return
  end   
   --将病区，病房，病床，病人信息插入到 临时表
   insert into #电子一览表(	
   病区代码 ,
   病区名称 ,
   责任医生代码1 ,
   责任医生姓名1 ,
   责任医生代码2 ,
   责任医生姓名2 ,
   责任医生代码3 ,
   责任医生姓名3 ,  
   责任护士代码1 ,
   责任护士姓名1 ,
   责任护士代码2 ,
   责任护士姓名2 ,
   责任护士代码3 ,
   责任护士姓名3 ,
   责任护士代码4 ,
   责任护士姓名4 ,
   值班医生代码1 ,  
   值班医生姓名1 ,  
   值班医生代码2 ,  
   值班医生姓名2 ,  
   值班医生代码3 ,  
   值班医生姓名3    
	)
   select a.wardid,a.wardname,b.doctor1,'',b.doctor2 ,'',b.doctor3,'',
     b.nurse1,'',b.nurse2,'',b.nurse3,'',b.nurse4,'',
     b.workdoctor1,'',b.workdoctor2,'',b.workdoctor3,''
   from t_ward a ,t_ward_work b
   where a.wardid=@wardid 
		and b.wardid=a.wardid
   
   -------------------
   update #电子一览表 set 责任医生姓名1=b.name,责任医生电话1=b.tel
   from #电子一览表 a ,t_worker b
   where a.责任医生代码1=b.workid
   update #电子一览表 set 责任医生姓名2=b.name,责任医生电话2=b.tel
   from #电子一览表 a ,t_worker b
   where a.责任医生代码2=b.workid   
   update #电子一览表 set 责任医生姓名3=b.name,责任医生电话3=b.tel
   from #电子一览表 a ,t_worker b
   where a.责任医生代码3=b.workid 
   update #电子一览表 set 责任护士姓名1=b.name,责任护士电话1=b.tel
   from #电子一览表 a ,t_worker b
   where a.责任护士代码1=b.workid   
   update #电子一览表 set 责任护士姓名2=b.name,责任护士电话2=b.tel
   from #电子一览表 a ,t_worker b
   where a.责任护士代码2=b.workid     
   update #电子一览表 set 责任护士姓名3=b.name,责任护士电话3=b.tel
   from #电子一览表 a ,t_worker b
   where a.责任护士代码3=b.workid             
   update #电子一览表 set 责任护士姓名4=b.name,责任护士电话4=b.tel
   from #电子一览表 a ,t_worker b
   where a.责任护士代码4=b.workid     
   update #电子一览表 set 值班医生姓名1=b.name,值班医生电话1=b.tel
   from #电子一览表 a ,t_worker b
   where a.值班医生代码1=b.workid     
   update #电子一览表 set 值班医生姓名2=b.name,值班医生电话2=b.tel
   from #电子一览表 a ,t_worker b
   where a.值班医生代码2=b.workid   
   update #电子一览表 set 值班医生姓名3=b.name,值班医生电话3=b.tel
   from #电子一览表 a ,t_worker b
   where a.值班医生代码3=b.workid            
      
   select * from #电子一览表
   drop table #电子一览表
   return

go

