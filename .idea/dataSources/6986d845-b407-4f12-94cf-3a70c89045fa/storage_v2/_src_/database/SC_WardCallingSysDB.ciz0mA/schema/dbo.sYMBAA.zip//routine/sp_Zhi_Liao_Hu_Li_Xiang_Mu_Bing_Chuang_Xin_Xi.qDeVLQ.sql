-------------------------------------
/*
存储过程名称：sp_治疗护理项目病床信息
功能：根据ip参数获取本病区的治疗护理项目病床信息.
返回说明:
a.没找到对应ip的电子一览表设置,返回result字段 ,result 内容为：未找到电子一览表+ip
b.打到对应ip的电子一览表设置,返回这个病区的所有治疗护理项目病床信息,
返回内容包括：
  (病区代码 varchar(10),
   病区名称 varchar(30),
   项目名称 varchar(50),  
   项目分类 varchar(50),
   病床 varchar(100))
示例：
exec sp_治疗护理项目病床信息 '192.168.2.95'

*/
-------------------------------------
CREATE procedure [dbo].[sp_治疗护理项目病床信息]
  @ip varchar(20)
as 
  declare @wardid varchar(10)  
  select @wardid=wardid from t_device where ip=@ip and devicetype=5
  set @wardid=ISNULL(@wardid,'')

  create table #电子一览表
  (病区代码 varchar(10),
   病区名称 varchar(30),
   项目名称 varchar(50),  
   项目分类 varchar(50),
   病床 varchar(100))
   
  if (@wardid='' ) --没有找到对应的病区代码
  begin
    select * from #电子一览表
    drop table #电子一览表
	return
  end   
   --将病区，病房，病床，病人信息插入到 临时表
   insert into #电子一览表(
	病区代码,病区名称,项目名称,  
   项目分类,
   病床
	)
   select a.wardid,a.wardname,b.itemname,b.note,b.bedid
   from t_ward a ,t_ward_nurseitem b  
   where a.wardid=@wardid 
		and b.wardid=a.wardid    

   select * from #电子一览表
   drop table #电子一览表
   return



go

