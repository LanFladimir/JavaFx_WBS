create view [dbo].[v_t_ward_work]
as
select *,
(select wardname from t_ward w where w.wardid=c.wardid) as wardname,
(select name from t_worker w where w.workid=c.doctor1 and w.workertype='1') as doctor1name,
(select name from t_worker w where w.workid=c.doctor2 and w.workertype='1') as doctor2name,
(select name from t_worker w where w.workid=c.doctor3 and w.workertype='1') as doctor3name,
(select name from t_worker w where w.workid=c.doctor4 and w.workertype='1') as doctor4name,
(select name from t_worker w where w.workid=c.nurse1 and w.workertype='2') as nurse1name,
(select name from t_worker w where w.workid=c.nurse2 and w.workertype='2') as nurse2name,
(select name from t_worker w where w.workid=c.nurse3 and w.workertype='2') as nurse3name,
(select name from t_worker w where w.workid=c.nurse4 and w.workertype='2') as nurse4name,
(select name from t_worker w where w.workid=c.workdoctor1 and w.workertype='1') as workdoctor1name,
(select name from t_worker w where w.workid=c.workdoctor2 and w.workertype='1') as workdoctor2name,
(select name from t_worker w where w.workid=c.workdoctor3 and w.workertype='1') as workdoctor3name,
(select username from t_sys_users u where u.userid=c.creator) createname,
(select username from t_sys_users u where u.userid=c.editor) editname
 from t_ward_work c
go

