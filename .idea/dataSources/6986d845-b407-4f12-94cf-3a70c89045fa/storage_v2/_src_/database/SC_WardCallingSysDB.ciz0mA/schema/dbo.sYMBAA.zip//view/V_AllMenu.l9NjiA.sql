

create view [dbo].[V_AllMenu]
as
SELECT     f.funcid, f.funcname, f.isuse AS fisuse, m.menuid, m.pmenuid, m.menuname, m.filename, m.ico, m.isexpand, m.isuse AS menuisuse, m.isvisible, m.displayorder
FROM         dbo.t_sys_func AS f INNER JOIN
                      dbo.t_sys_m_menufunc AS mf ON f.funcid = mf.funcid INNER JOIN
                      dbo.t_sys_menu AS m ON m.menuid = mf.menuid
go

