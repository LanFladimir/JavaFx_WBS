create view [dbo].[v_wardbedinfo]
as
select b.*,w.wardid from v_t_ward w
join v_t_sickroom r on w.wardid=r.wardid
join v_t_sickbed b on r.roomid=b.roomid
go

