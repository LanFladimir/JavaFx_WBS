create view [dbo].[V_t_sys_logs]
as
select *,(SELECT     username
FROM          dbo.t_sys_users AS u
WHERE      (userid = s.creator)) AS creatname,
case logisexport when '1' then '已导出' when '0' then '未导出' end as logisexportname
from 
dbo.t_sys_logs s
go

