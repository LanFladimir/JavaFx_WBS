CREATE procedure [dbo].[getWardOtherServiceGroupReport]               
 @wardid varchar(20),                
 @begindate varchar(10),        
 @enddate varchar(10)        
-- getWardOtherServiceGroupReport 1,'2016-01-01','2016-01-01'        
--@wardid 病区代码        
--@begindate 报表开始日期          
--@enddate 报表结束日期        
as           
 declare @great int        
 declare @better int        
 declare @good int        
 declare @bad int        
 set @great=60        
 set @better=120        
 set @good=180        
 set @bad=300             
 declare @cnt int                       
 declare @deviceid varchar(10)                
 declare @devicename varchar(100)           
 declare @devicealias varchar(100)               
 --建立临时表.                
 create table #listreport               
 (序号 int IDENTITY (1,1),        
  班别 varchar(20),        
  呼叫者  varchar(30),        
  病区    varchar(100),        
  病房   varchar(100),        
  床位     varchar(100),          
  呼叫时间 varchar(20),        
  处理时间 varchar(20),        
  是否增援 varchar(2),  --是否        
  紧急呼叫 varchar(4)  --是否紧急呼叫          
 )                
                   
                   
 select @cnt=count(*) from t_ward where wardid=@wardid         
 if @cnt>0                 
 begin                
   --查询出此ip对应的病区代码，病房代码，设备代码，设备名称.        
 --   insert into #listreport(班别,呼叫者,病区,        
 -- 病房,床位,呼叫时间,处理时间,        
 -- 是否增援, 紧急呼叫)      
    insert into #listreport(班别,呼叫者,病区,        
  病房,床位,呼叫时间,处理时间,        
  是否增援, 紧急呼叫)                 
    select case when convert(varchar(8),l.dialtime,108)<'08:00:00' then '早班'        
       when convert(varchar(8),l.dialtime,108)<'16:00:00' then '中班'        
            when convert(varchar(8),l.dialtime,108)<'24:00:00' then '晚班' end 班别,        
   isnull(h.patient_name,l.in_hospital_no),w.wardname,        
      r.roomname,b.bedname,        
     convert(varchar(20),l.dialtime,120),convert(varchar(20),l.starttime,120),           
     case when l.status=2 then '是' else '否' end,        
     case when l.type=2 then  '紧急' else '普通' end            
    from t_calllog l        
    left outer join  t_ward w on l.wardid=w.wardid        
    left outer join  t_sickroom r on l.wardid=r.wardid and l.roomid=r.roomid        
    left outer join t_sickbed b on l.roomid=b.roomid  and l.bedid=b.bedid-- l.wardid=b.wardid and     
   left outer join t_inhospital h on l.in_hospital_no=h.in_hospital_no        
   where w.wardid=@wardid            
   and dialtime between @begindate and dateadd(d,1,@enddate)    
   order by dialtime         
   --更新病人信息                
   --更新医生信息，护士信息                
   --返回门口屏对应的信息            
   select IDENTITY(int,1,1) as  序号,班别,sum(case when 是否增援='是' then 1 else 0 end)  数量, count(*) 呼叫总数,        
     case when count(*)=0 then '100%' else         
     convert(varchar,floor(sum(case when 是否增援='是' then 1 else 0 end)*100/count(*) ))+'%' end 比例         
   into #t         
   from #listreport  group by 班别         
           
   select '合计'  序号,'    ' 班别,sum(case when 是否增援='是' then 1 else 0 end)  数量, count(*) 呼叫总数,        
     case when count(*)=0 then '100%' else         
     convert(varchar,floor(sum(case when 是否增援='是' then 1 else 0 end)*100/count(*) ))+'%' end 比例         
   into #t1         
   from #listreport        
        
   insert into #t1(序号,班别,数量,呼叫总数,比例)
   select '1','早班',0,0,'0%' where not exists(select 1 from #t where 班别='早班')

   insert into #t1(序号,班别,数量,呼叫总数,比例)
   select '2','中班',0,0,'0%' where not exists(select 1 from #t where 班别='中班')
   
   insert into #t1(序号,班别,数量,呼叫总数,比例)
   select '3','晚班',0,0,'0%' where not exists(select 1 from #t where 班别='晚班')
         
   --insert into #t1(lb,序号,班别,数量,呼叫总数,比例)
   --select 5,' ','','','','' 
   --insert into #t1(lb,序号,班别,数量,呼叫总数,比例)
   --select 6,' ','','','','' 
   --insert into #t1(lb,序号,班别,数量,呼叫总数,比例)
   --select 7,' ','','','',''       
   
   select case when 班别='早班' then '1' when  班别='中班' then '2' when  班别='晚班' then '3' else '4' end as xh,
       班别 as bb,数量 as sl,呼叫总数 as hjzs,比例 as bl from #t        
   union        
   select 序号 xh,班别 bb,数量 sl,呼叫总数 hjzs,比例 bl from #t1    
   order by xh      
   drop table #t        
   drop table #t1        
             
 end                
 else                
 begin                
   --返回空表                
   select 0 lb,'0' xh,' ' bb,0 sl,0 hjzs,'' bl  where 1<>1        
 end                
--删除临时表                
 drop table #listreport
go

