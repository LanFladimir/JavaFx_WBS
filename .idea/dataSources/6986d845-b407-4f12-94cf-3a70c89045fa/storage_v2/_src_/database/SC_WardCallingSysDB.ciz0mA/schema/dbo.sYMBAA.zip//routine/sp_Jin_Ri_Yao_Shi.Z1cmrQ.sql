
-------------------------------------
/*
存储过程名称：sp_今日要事
功能：根据ip参数获取本病区的治疗护理项目病床信息.
返回说明:
找到对应ip的电子一览表设置,返回这个病区的所有治疗护理项目病床信息,
返回内容包括：
  (病区代码 varchar(10),
   病区名称 varchar(30),
   内容 varchar(200))
示例：
exec sp_今日要事 '192.168.2.95'

*/
-------------------------------------
create procedure  [dbo].[sp_今日要事]
  @ip varchar(20)
as 
  declare @wardid varchar(10)  
  select @wardid=wardid from t_device where ip=@ip and devicetype=5
  set @wardid=ISNULL(@wardid,'')

  create table #电子一览表
  (病区代码 varchar(10),
   病区名称 varchar(30),
   内容 varchar(200)
   )
   
  if (@wardid='' ) --没有找到对应的病区代码
  begin
    select * from #电子一览表
    drop table #电子一览表
	return
  end   
   --将病区，病房，病床，病人信息插入到 临时表
   insert into #电子一览表(	
   病区代码 ,
   病区名称 ,
   内容
	)
   select a.wardid,a.wardname,b.todaynote 
   from t_ward a ,t_ward_work b
   where a.wardid=@wardid 
		and b.wardid=a.wardid

   select * from #电子一览表
   drop table #电子一览表
   return

go

