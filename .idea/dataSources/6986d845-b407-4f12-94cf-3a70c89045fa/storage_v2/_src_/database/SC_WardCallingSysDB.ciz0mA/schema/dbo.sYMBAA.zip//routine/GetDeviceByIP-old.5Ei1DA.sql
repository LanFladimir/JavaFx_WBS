--GetDeviceByIP '192.168.2.190'      
CREATE procedure [dbo].[GetDeviceByIP-old]      
 @ip varchar(20)      
as      
 declare @cnt int      
 declare @wardid varchar(10)        
 declare @deviceid varchar(10)      
 declare @devicename varchar(100)      
 --建立临时表.   
/*    
 create table #beds     
 ( deviceid varchar(10),devicename varchar(100),      
   wardid varchar(10),wardname varchar(100),      
   roomid varchar(10),roomname varchar(100),      
   bedid varchar(10),bedname varchar(100),      
   patient_name varchar(30),in_hospital_no varchar(10),    
  PATIENT_CARD varchar (32),  
  PATIENT_SEX varchar(2),  
  PATIENT_AGE varchar(10),  
  PATIENT_GRADE varchar(20),  
  IN_HOSPITAL_TIME datetime,  
  LEAVE_HOSPITAL_TIME datetime,  
  PATIENT_DIAGNOSIS varchar(100),  
  PATIENT_ALLERGY varchar(100),  
  PATIENT_FOOD varchar(10),       
   doctorid varchar(10),doctorname varchar(30),doctorsex varchar(2),doctorzc varchar(20),doctorphoto varchar(100),      
   nurseid varchar(10),nursename varchar(30),nursesex varchar(2),nursezc varchar(20),nursephoto varchar(100)      
 )      
*/         
         
 select @cnt=count(*) from t_device where ip=@ip      
 if @cnt>0       
 begin      
   --查询出此ip对应的病区代码，病房代码，设备代码，设备名称.      
   select @wardid=wardid,@deviceid=deviceid,@devicename=devicename       
   from  t_device where ip=@ip      
   --将病区，病房，病床信息插入到临时表中。      
 /*  insert into #beds(deviceid ,devicename ,      
   wardid ,wardname ,      
   roomid ,roomname ,      
   bedid ,bedname ,      
   patient_name ,in_hospital_no ,   
  PATIENT_CARD,  
  PATIENT_SEX,  
  PATIENT_AGE,  
  PATIENT_GRADE,  
  IN_HOSPITAL_TIME,  
  LEAVE_HOSPITAL_TIME,  
  PATIENT_DIAGNOSIS,  
  PATIENT_ALLERGY,  
  PATIENT_FOOD,      
   doctorid ,doctorname ,doctorsex ,doctorzc ,doctorphoto,       
   nurseid ,nursename ,nursesex ,nursezc ,nursephoto)      
   select @deviceid ,@devicename ,      
   w.wardid ,w.wardname ,      
   r.roomid ,r.roomname ,      
   b.bedid ,b.bedname,h.patient_name,in_hospital_no,      
  PATIENT_CARD,  
  PATIENT_SEX,  
  PATIENT_AGE,  
  PATIENT_GRADE,  
  IN_HOSPITAL_TIME,  
  LEAVE_HOSPITAL_TIME,  
  PATIENT_DIAGNOSIS,  
  PATIENT_ALLERGY,  
  PATIENT_FOOD,      
   h.doctor,k.xm,k.xb,k.zc,k.zpwz,      
   h.nurse,n.xm,n.xb,n.zc,n.zpwz      
    from t_ward w,t_sickroom r,t_sickbed b       
   left outer join t_inhospital h on h.wardid=b.wardid and h.roomid=b.roomid and h.bedid=b.bedid and h.status=1      
   left outer join t_worker k on h.doctor=k.dm and k.lb=1      
   left outer join t_worker n on h.nurse=n.dm and n.lb=2      
   where w.wardid=r.wardid and w.wardid=b.wardid and r.roomid=b.roomid      
   and r.wardid=@wardid       
   --更新病人信息      
   --更新医生信息，护士信息      
   --返回门口屏对应的信息      
   select * from #beds      
*/  
   select d.autoid,d.deviceid,devicename,d.alias,devicetype,ip,display_ui,d.wardid,w.wardname,w.alias wardalias,  
   d.roomid,r.roomname,r.alias roomalias from t_device d   
      left outer join t_ward w on d.wardid=w.wardid  
      left outer join t_sickroom r on d.wardid=r.wardid and d.roomid=r.roomid   
   where d.wardid=@wardid
 end      
 else      
 begin      
   --返回空表      
   select d.autoid,d.deviceid,devicename,d.alias,devicetype,ip,display_ui,d.wardid,w.wardname,w.alias wardalias,  
     d.roomid,r.roomname,r.alias roomalias from t_device d   
      left outer join t_ward w on d.wardid=w.wardid  
      left outer join t_sickroom r on d.wardid=r.wardid and d.roomid=r.roomid   
   where 1<>1  
 end      
--删除临时表      
-- drop table #beds      

go

