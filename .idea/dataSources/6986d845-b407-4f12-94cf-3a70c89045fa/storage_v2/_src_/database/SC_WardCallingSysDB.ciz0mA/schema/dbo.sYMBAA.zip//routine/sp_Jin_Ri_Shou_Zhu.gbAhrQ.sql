
-------------------------------------
/*
存储过程名称：sp_今日手术
功能：根据ip参数获取本病区的治疗护理项目病床信息.
返回说明:
找到对应ip的电子一览表设置,返回这个病区的所有治疗护理项目病床信息,
返回内容包括：
  (病区代码 varchar(10),
   病区名称 varchar(30),
   病房代码 varchar(10),
   病房名称 varchar(30),
   病床代码 varchar(10),
   病床名称 varchar(30),   
   项目名称 varchar(50),  
   项目分类 varchar(50),
   病床 varchar(100))
示例：
exec sp_今日手术 '192.168.2.95'

*/
-------------------------------------
CREATE procedure [dbo].[sp_今日手术]
  @ip varchar(20)
as 
  declare @wardid varchar(10)  
  select @wardid=wardid from t_device where ip=@ip and devicetype=5
  set @wardid=ISNULL(@wardid,'')

  create table #电子一览表
  (住院号 varchar(10),
   姓名  varchar(20),
   病区代码 varchar(10),
   病区名称 varchar(30),
   病房代码 varchar(10),
   病房名称 varchar(30),
   病床代码 varchar(10),
   病床名称 varchar(30), 
   手术名称 varchar(50),
   麻醉类型 varchar(30)
   )
   
  if (@wardid='' ) --没有找到对应的病区代码
  begin
    select * from #电子一览表
    drop table #电子一览表
	return
  end   
   --将病区，病房，病床，病人信息插入到 临时表
   insert into #电子一览表(
	住院号 ,
    姓名  ,
   病区代码 ,
   病区名称 ,
   病房代码 ,
   病房名称 ,
   病床代码 ,
   病床名称 , 
   手术名称 ,
   麻醉类型
	)
   select d.in_hospital_no,d.patient_name , a.wardid,a.wardname,b.roomid,b.roomname,c.bedid,c.bedname,
	  e.surgeryname,e.narcosis
   from t_ward a ,t_sickroom b,t_sickbed c,t_inhospital d,t_inp_surgery e
   where a.wardid=@wardid 
		and b.wardid=a.wardid
        and c.roomid=b.roomid 
        and d.bedid=c.bedid
        and d.in_hospital_no=e.in_hospital_no
        and e.status=0
        and CONVERT(varchar(10),getdate(),120)=CONVERT(varchar(10),e.surgerytime,120)

   select * from #电子一览表
   drop table #电子一览表
   return



go

