
-------------------------------------
/*
存储过程名称：sp_备注信息
功能：根据ip参数获取本病区的备注信息信息.
返回说明:
找到对应ip的电子一览表设置,返回这个病区的所有备注信息,
返回内容包括：
  (病区代码 varchar(10),
   病区名称 varchar(30),
   顺序号 varchar(10),
   备注信息 varchar(100) 
   )
示例：
exec sp_备注信息 '192.168.2.95'

*/
-------------------------------------
create procedure  [dbo].[sp_备注信息]
  @ip varchar(20)
as 
  declare @wardid varchar(10)  
  select @wardid=wardid from t_device where ip=@ip and devicetype=5
  set @wardid=ISNULL(@wardid,'')

  create table #电子一览表
  (病区代码 varchar(10),
   病区名称 varchar(30),
   顺序号 varchar(10),
   备注信息 varchar(100)  
   )
   
  if (@wardid='' ) --没有找到对应的病区代码
  begin
    select * from #电子一览表
    drop table #电子一览表
	return
  end   
   --将病区，病房，病床，病人信息插入到 临时表
   insert into #电子一览表(	
	   病区代码 ,
	   病区名称 ,
	   顺序号 ,
	   备注信息         
	)
   select a.wardid,a.wardname,b.seq,b.note
   from t_ward a ,t_ward_note b
   where a.wardid=@wardid 
		and b.wardid=a.wardid
		and b.status=1 
		and CONVERT(varchar(10),getdate(),120) between CONVERT(varchar(10),begintime,120)
			and CONVERT(varchar(10),endtime,120)

   -------------------
         
      
   select * from #电子一览表
   drop table #电子一览表
   return

go

