create view [dbo].[v_inp_surgery]
as
SELECT     c.autoid, c.in_hospital_no, c.surgerytime, c.surgeryname, c.status, c.narcosis, c.doctor, c.assistant, c.anesthetizedoctor,
 c.notation, c.ssdbh, c.creator, c.createtime, c.editor, c.modifytime, 
                      CASE c.status WHEN '1' THEN '手术中' WHEN '0' THEN '已安排' WHEN '2' THEN '手术完成' END AS statustext,
                          (SELECT     name
                            FROM          dbo.t_worker AS w
                            WHERE      (workid = c.doctor) AND (workertype = '1')) AS doctorname,
                          (SELECT     name
                            FROM          dbo.t_worker AS w
                            WHERE      (workid = c.doctor) AND (workertype = '1')) AS assistantname,
                          (SELECT     name
                            FROM          dbo.t_worker AS w
                            WHERE      (workid = c.doctor) AND (workertype = '1')) AS anesthetizedoctorname,
                          (SELECT     username
                            FROM          dbo.t_sys_users AS u
                            WHERE      (userid = c.creator)) AS createname,
                          (SELECT     username
                            FROM          dbo.t_sys_users AS u
                            WHERE      (userid = c.editor)) AS editname
FROM         dbo.t_inp_surgery AS c left join v_t_inhospital h
on c.in_hospital_no=h.in_hospital_no
go

