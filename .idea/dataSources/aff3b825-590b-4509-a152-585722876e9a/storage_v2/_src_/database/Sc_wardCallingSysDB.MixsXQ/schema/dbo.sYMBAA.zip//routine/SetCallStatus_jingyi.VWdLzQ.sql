--@ip 呼叫主机的ip,用于查找对应的病区代码 @wardid
--@terminaltype  终端类型,1-床头分机,2-卫浴分机(T_Terminal.TERMINALTYPE
--@terminalid 终端地址  (T_Terminal.TERMINALID)
--@callstatus 呼叫状态 1-呼叫  0-取消、挂断 T_Terminal.callstatus
CREATE procedure [dbo].[SetCallStatus]  
 @ip varchar(20),  
 @terminaltype varchar(10),  
 @terminalid varchar(10),  
 @callstatus int           
as            
 declare @cnt int            
 declare @wardid varchar(10)                     
 declare @deviceid varchar(10)            
 declare @devicename varchar(100)            
 declare @devicealias varchar(100)   
 --SetCallStatus 'aa','1','4',1
   
--主机      
 --set @ip='192.168.56.101'  --//310103
 print @ip
 
 select @cnt=count(*) from t_ward where hiswardno=@ip
 --select * from t_device where devicetype=1
 print @cnt     
 if @cnt>0             
 begin            
   --查询出此ip对应的病区代码         
   --select @wardid=wardid,@deviceid=DEVICEID,@devicealias=ALIAS       
   --from  t_device where devicetype=1 and ip=@ip  
   
   select @wardid=wardid from t_ward where hiswardno=@ip 
   
 INSERT INTO t_call_log(terminaltype,ip,wardid,terminalid,status)VALUES(@terminaltype,@ip,@wardid,@terminalid,@callstatus)  
    
   if @terminaltype=1 --床头分机
   begin
	   update T_Terminal set callstatus=@callstatus,calltime=getdate()   
	  where TERMINALTYPE=@terminaltype and TERMINALID=@terminalid  
	    and bedid in (select bedid from t_sickbed where roomid in
			(select roomid from t_sickroom where wardid=@wardid))
   end
   else
   begin
	   update T_Terminal set callstatus=@callstatus,calltime=getdate()   
	  where TERMINALTYPE=@terminaltype and TERMINALID=@terminalid  
	    and roomid in (select roomid from t_sickroom where wardid=@wardid)   
   end  
   select 1            
 end            
 else            
 begin            
   select 0       
 end
go

