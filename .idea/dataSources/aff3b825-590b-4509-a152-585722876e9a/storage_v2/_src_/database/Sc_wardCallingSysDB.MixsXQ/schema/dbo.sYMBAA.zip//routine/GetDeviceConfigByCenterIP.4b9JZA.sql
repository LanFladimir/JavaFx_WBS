CREATE procedure [dbo].[GetDeviceConfigByCenterIP]      
 @ip varchar(20)      
as   
--GetDeviceConfigByCenterIP '192.168.2.190'         
 declare @cnt int      
 declare @wardid varchar(10)        
 declare @deviceid varchar(10)      
 declare @devicename varchar(100)      

 select @cnt=count(*) from t_device where devicetype=1 and ip=@ip      
 if @cnt>0       
 begin          
   select * from t_config where section=@ip  
 end      
 else      
 begin      
   --返回空表      
   select * from t_config 
   where 1<>1  
 end


go

