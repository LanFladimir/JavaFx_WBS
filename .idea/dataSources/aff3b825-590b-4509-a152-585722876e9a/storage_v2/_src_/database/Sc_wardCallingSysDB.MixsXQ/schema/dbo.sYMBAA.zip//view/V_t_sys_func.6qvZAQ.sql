CREATE VIEW [dbo].[V_t_sys_func]
as
SELECT     autoid, funcid, funcname, isuse, CASE isuse WHEN '1' THEN '是' ELSE '否' END AS isusename, creator,
                          (SELECT     username
                            FROM          dbo.t_sys_users AS u
                            WHERE      (userid = f.creator)) AS creatname, createtime, editor,
                          (SELECT     username
                            FROM          dbo.t_sys_users AS u
                            WHERE      (userid = f.editor)) AS editname, modifytime, ico
FROM         dbo.t_sys_func AS f
go

