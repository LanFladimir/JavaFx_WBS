
create view [dbo].[V_FuncMenuInfo]
AS
SELECT     dbo.t_sys_func.funcid, dbo.t_sys_func.funcname, dbo.t_sys_menu.menuid, dbo.t_sys_menu.menuname, dbo.t_sys_menu.filename, dbo.t_sys_menu.pmenuid, dbo.t_sys_menu.ico, 
dbo.t_sys_menu.displayorder
FROM     
dbo.t_sys_menu left join dbo.t_sys_m_menufunc ON dbo.t_sys_menu.menuid = dbo.t_sys_m_menufunc.menuid
left join t_sys_func ON dbo.t_sys_func.funcid = dbo.t_sys_m_menufunc.funcid
WHERE     (dbo.t_sys_menu.isuse = '1') or (dbo.t_sys_func.isuse = '1')
go

