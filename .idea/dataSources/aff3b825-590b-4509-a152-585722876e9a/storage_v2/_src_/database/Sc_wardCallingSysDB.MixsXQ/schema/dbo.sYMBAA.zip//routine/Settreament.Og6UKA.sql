CREATE procedure Settreament(  
@inp_no varchar(30),  
@ip varchar(30)  
)  
/*  
SetNurseCheck   
设置护士巡视记录  
参数 @inp_no 住院号  
根据住院号记录护士处置信息
示例：SetNurseCheck '01255690','192.168.57.81'
*/  
as  
begin  
  declare @wardid varchar(20)  
  declare @roomid varchar(20)  
  declare @timecode varchar(20)    
  if exists(  
  select 1 from t_inhospital where in_hospital_no=@inp_no and status=1)  
  begin  
    insert into t_treament(in_hospital_no,createtime,hostip)      
    select @inp_no,GETDATE(),@ip          
  end    
end
go

