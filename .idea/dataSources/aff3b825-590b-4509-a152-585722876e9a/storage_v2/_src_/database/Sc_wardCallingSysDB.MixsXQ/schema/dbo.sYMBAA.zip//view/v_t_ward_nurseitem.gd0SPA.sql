create view [dbo].[v_t_ward_nurseitem]
as
SELECT     autoid, wardid, itemname, bedid, note, creator, createtime, editor, modifytime,
                          (SELECT     wardname
                            FROM          dbo.t_ward AS w
                            WHERE      (wardid = c.wardid)) AS wardname,
                           bedname,
                          (SELECT     username
                            FROM          dbo.t_sys_users AS u
                            WHERE      (userid = c.creator)) AS createname,
                          (SELECT     username
                            FROM          dbo.t_sys_users AS u
                            WHERE      (userid = c.editor)) AS editname
FROM         dbo.t_ward_nurseitem AS c
go

