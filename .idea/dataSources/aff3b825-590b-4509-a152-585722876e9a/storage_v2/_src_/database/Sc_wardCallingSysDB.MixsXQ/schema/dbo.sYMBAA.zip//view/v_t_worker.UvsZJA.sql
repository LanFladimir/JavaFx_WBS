

CREATE VIEW [dbo].[v_t_worker]
AS
SELECT     autoid, workid, name, sex, age, title, workertype, tel, creator, createtime, editor, modifytime, deptid, CASE sex WHEN '1' THEN '男' WHEN '0' THEN '女' END AS sextext, 
                      CASE workertype WHEN '1' THEN '医生' WHEN '2' THEN '护士' END AS workertypetext,
                          (SELECT     deptname
                            FROM          dbo.t_sys_dept AS d
                            WHERE      (deptid = c.deptid)) AS deptname,
                          (SELECT     username
                            FROM          dbo.t_sys_users AS u
                            WHERE      (userid = c.creator)) AS createname,
                          (SELECT     username
                            FROM          dbo.t_sys_users AS u
                            WHERE      (userid = c.editor)) AS editname,
                            wardid,(select wardname from t_ward w where c.wardid=w.wardid)wardname
FROM         dbo.t_worker AS c

go

