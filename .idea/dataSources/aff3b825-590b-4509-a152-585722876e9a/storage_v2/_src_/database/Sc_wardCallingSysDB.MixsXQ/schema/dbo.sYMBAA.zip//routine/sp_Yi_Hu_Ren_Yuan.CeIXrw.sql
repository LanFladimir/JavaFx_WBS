
-------------------------------------
/*
存储过程名称：sp_医护人员
功能：根据ip参数获取本病区的医护人员信息.
返回说明:
找到对应ip的电子一览表设置,返回这个病区的所有医护人员,
返回内容包括：
  (病区代码 varchar(10),
   病区名称 varchar(30),
   责任医生代码1 varchar(30),
   责任医生姓名1 varchar(30),
   责任医生代码2 varchar(30),
   责任医生姓名2 varchar(30),
   责任医生代码3 varchar(30),
   责任医生姓名3 varchar(30),  
   责任护士代码1 varchar(30),
   责任护士姓名1 varchar(30),
   责任护士代码2 varchar(30),
   责任护士姓名2 varchar(30),
   责任护士代码3 varchar(30),
   责任护士姓名3 varchar(30),
   责任护士代码4 varchar(30),
   责任护士姓名4 varchar(30),
   值班医生代码1 varchar(30),  
   值班医生姓名1 varchar(30),  
   值班医生代码2 varchar(30),  
   值班医生姓名2 varchar(30),  
   值班医生代码3 varchar(30),  
   值班医生姓名3 varchar(30)  
   )
示例：
exec sp_医护人员 '192.168.57.55'
select * from t_ward_work
select * from t_device where devicetype=5

*/
-------------------------------------
CREATE procedure  [dbo].[sp_医护人员]
  @ip varchar(20)
as 
  declare @wardid varchar(10)  
  select @wardid=wardid from t_device where ip=@ip and devicetype=5
  set @wardid=ISNULL(@wardid,'')

  create table #电子一览表
  (病区代码 varchar(10),
   病区名称 varchar(30),
   责任医生代码1 varchar(30),
   责任医生姓名1 varchar(30),
   责任医生电话1 varchar(30),
   责任医生代码2 varchar(30),
   责任医生姓名2 varchar(30),
   责任医生电话2 varchar(30),
   责任医生代码3 varchar(30),
   责任医生姓名3 varchar(30),
   责任医生电话3 varchar(30),  
   责任医生代码4 varchar(30),
   责任医生姓名4 varchar(30),
   责任医生电话4 varchar(30),
   责任医生代码5 varchar(30),
   责任医生姓名5 varchar(30),
   责任医生电话5 varchar(30),
   责任医生代码6 varchar(30),
   责任医生姓名6 varchar(30),
   责任医生电话6 varchar(30),  
   责任医生代码7 varchar(30),
   责任医生姓名7 varchar(30),
   责任医生电话7 varchar(30),
   责任医生代码8 varchar(30),
   责任医生姓名8 varchar(30),
   责任医生电话8 varchar(30),
   责任医生代码9 varchar(30),
   责任医生姓名9 varchar(30),
   责任医生电话9 varchar(30),   
   责任医生代码10 varchar(30),
   责任医生姓名10 varchar(30),
   责任医生电话10 varchar(30),
   责任医生代码11 varchar(30),
   责任医生姓名11 varchar(30),
   责任医生电话11 varchar(30),
   责任医生代码12 varchar(30),
   责任医生姓名12 varchar(30),
   责任医生电话12 varchar(30),        
   责任护士代码1 varchar(30),
   责任护士姓名1 varchar(30),
   责任护士电话1 varchar(30),
   责任护士代码2 varchar(30),
   责任护士姓名2 varchar(30),
   责任护士电话2 varchar(30),
   责任护士代码3 varchar(30),
   责任护士姓名3 varchar(30),
   责任护士电话3 varchar(30),
   责任护士代码4 varchar(30),
   责任护士姓名4 varchar(30),
   责任护士电话4 varchar(30),
   责任护士代码5 varchar(30),
   责任护士姓名5 varchar(30),
   责任护士电话5 varchar(30),  
   责任护士代码6 varchar(30),
   责任护士姓名6 varchar(30),
   责任护士电话6 varchar(30),    
   值班医生代码1 varchar(30),  
   值班医生姓名1 varchar(30),  
   值班医生电话1 varchar(30),  
   值班医生代码2 varchar(30),  
   值班医生姓名2 varchar(30),  
   值班医生电话2 varchar(30),  
   值班医生代码3 varchar(30),  
   值班医生姓名3 varchar(30),
   值班医生电话3 varchar(30),
   座机号码  varchar(30)
   )
   
  if (@wardid='' ) --没有找到对应的病区代码
  begin
    select * from #电子一览表
    drop table #电子一览表
	return
  end   
   --将病区，病房，病床，病人信息插入到 临时表
   insert into #电子一览表(	
   病区代码 ,
   病区名称 ,
   责任医生代码1 ,
   责任医生姓名1 ,
   责任医生代码2 ,
   责任医生姓名2 ,
   责任医生代码3 ,
   责任医生姓名3 ,  
   责任医生代码4 ,
   责任医生姓名4 ,
   责任医生代码5 ,
   责任医生姓名5 ,
   责任医生代码6 ,
   责任医生姓名6 , 
   责任医生代码7 ,
   责任医生姓名7 ,
   责任医生代码8 ,
   责任医生姓名8 ,
   责任医生代码9 ,
   责任医生姓名9 ,  
   责任医生代码10 ,
   责任医生姓名10 ,
   责任医生代码11 ,
   责任医生姓名11 ,
   责任医生代码12 ,
   责任医生姓名12 ,         
   责任护士代码1 ,
   责任护士姓名1 ,
   责任护士代码2 ,
   责任护士姓名2 ,
   责任护士代码3 ,
   责任护士姓名3 ,
   责任护士代码4 ,
   责任护士姓名4 ,
   责任护士代码5 ,
   责任护士姓名5 , 
   责任护士代码6 ,
   责任护士姓名6 ,     
   值班医生代码1 ,  
   值班医生姓名1 ,  
   值班医生代码2 ,  
   值班医生姓名2 ,  
   值班医生代码3 ,  
   值班医生姓名3,
   座机号码    
	)
   select a.wardid,a.wardname,b.doctor1,'',b.doctor2 ,'',b.doctor3,'',
   b.doctor4,'',b.doctor5 ,'',b.doctor6,'',
   b.doctor7,'',b.doctor8 ,'',b.doctor9,'',
   b.doctor10,'',b.doctor11 ,'',b.doctor12,'',
     b.nurse1,'',b.nurse2,'',b.nurse3,'',b.nurse4,'',
     b.nurse5,'',b.nurse6,'',
     b.workdoctor1,'',b.workdoctor2,'',b.workdoctor3,'',b.doctortel
   from t_ward a ,t_ward_work b
   where a.wardid=@wardid 
		and b.wardid=a.wardid
		
		
   
   -------------------
   update #电子一览表 set 责任医生姓名1=b.name,责任医生电话1=b.tel
   from #电子一览表 a ,t_worker b
   where a.责任医生代码1=b.workid
   update #电子一览表 set 责任医生姓名2=b.name,责任医生电话2=b.tel
   from #电子一览表 a ,t_worker b
   where a.责任医生代码2=b.workid   
   update #电子一览表 set 责任医生姓名3=b.name,责任医生电话3=b.tel
   from #电子一览表 a ,t_worker b
   where a.责任医生代码3=b.workid 

   update #电子一览表 set 责任医生姓名4=b.name,责任医生电话4=b.tel
   from #电子一览表 a ,t_worker b
   where a.责任医生代码4=b.workid
   update #电子一览表 set 责任医生姓名5=b.name,责任医生电话5=b.tel
   from #电子一览表 a ,t_worker b
   where a.责任医生代码5=b.workid   
   update #电子一览表 set 责任医生姓名6=b.name,责任医生电话6=b.tel
   from #电子一览表 a ,t_worker b
   where a.责任医生代码6=b.workid 
   
   update #电子一览表 set 责任医生姓名7=b.name,责任医生电话7=b.tel
   from #电子一览表 a ,t_worker b
   where a.责任医生代码7=b.workid
   update #电子一览表 set 责任医生姓名8=b.name,责任医生电话8=b.tel
   from #电子一览表 a ,t_worker b
   where a.责任医生代码8=b.workid   
   update #电子一览表 set 责任医生姓名9=b.name,责任医生电话9=b.tel
   from #电子一览表 a ,t_worker b
   where a.责任医生代码9=b.workid   
   
   update #电子一览表 set 责任医生姓名10=b.name,责任医生电话10=b.tel
   from #电子一览表 a ,t_worker b
   where a.责任医生代码10=b.workid
   update #电子一览表 set 责任医生姓名11=b.name,责任医生电话11=b.tel
   from #电子一览表 a ,t_worker b
   where a.责任医生代码11=b.workid   
   update #电子一览表 set 责任医生姓名12=b.name,责任医生电话12=b.tel
   from #电子一览表 a ,t_worker b
   where a.责任医生代码12=b.workid        


   update #电子一览表 set 责任护士姓名1=b.name,责任护士电话1=b.tel
   from #电子一览表 a ,t_worker b
   where a.责任护士代码1=b.workid   
   update #电子一览表 set 责任护士姓名2=b.name,责任护士电话2=b.tel
   from #电子一览表 a ,t_worker b
   where a.责任护士代码2=b.workid     
   update #电子一览表 set 责任护士姓名3=b.name,责任护士电话3=b.tel
   from #电子一览表 a ,t_worker b
   where a.责任护士代码3=b.workid             
   update #电子一览表 set 责任护士姓名4=b.name,责任护士电话4=b.tel
   from #电子一览表 a ,t_worker b
   where a.责任护士代码4=b.workid   
   update #电子一览表 set 责任护士姓名5=b.name,责任护士电话5=b.tel
   from #电子一览表 a ,t_worker b
   where a.责任护士代码5=b.workid  
   update #电子一览表 set 责任护士姓名6=b.name,责任护士电话6=b.tel
   from #电子一览表 a ,t_worker b
   where a.责任护士代码6=b.workid     
         
   update #电子一览表 set 值班医生姓名1=b.name,值班医生电话1=b.tel
   from #电子一览表 a ,t_worker b
   where a.值班医生代码1=b.workid     
   update #电子一览表 set 值班医生姓名2=b.name,值班医生电话2=b.tel
   from #电子一览表 a ,t_worker b
   where a.值班医生代码2=b.workid   
   update #电子一览表 set 值班医生姓名3=b.name,值班医生电话3=b.tel
   from #电子一览表 a ,t_worker b
   where a.值班医生代码3=b.workid            
      
   select * from #电子一览表
   drop table #电子一览表
   return


go

