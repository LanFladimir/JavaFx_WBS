create view [dbo].[v_t_eventlog]
as
select *,(select wardname from t_ward w where w.wardid=c.wardid) as wardname,
case type when '1' then '呼叫器' when '2' then '护士分机' end as typetext,
(select username from t_sys_users u where u.userid=c.creator) createname,
(select username from t_sys_users u where u.userid=c.editor) editname
 from t_eventlog c
go

