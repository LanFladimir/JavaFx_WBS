
-------------------------------------
/*
存储过程名称：sp_明日要事
功能：根据ip参数获取本病区的治疗护理项目病床信息.
返回说明:
找到对应ip的电子一览表设置,返回这个病区的所有治疗护理项目病床信息,
返回内容包括：
  (病区代码 varchar(10),
   病区名称 varchar(30),
   内容 varchar(200)
   内容1 varchar(200),
   内容2 varchar(200),
   内容3 varchar(200),
   内容4 varchar(200),
   内容5 varchar(200),
   内容6 varchar(200)    )
示例：
exec sp_明日要事 '192.168.57.28'

*/
-------------------------------------
CREATE procedure  [dbo].[sp_明日要事]
  @ip varchar(20)
as 
  declare @wardid varchar(10)  
  select @wardid=wardid from t_device where ip=@ip and devicetype=5
  set @wardid=ISNULL(@wardid,'')

  create table #电子一览表
  (病区代码 varchar(10),
   病区名称 varchar(30),
   内容 varchar(1000),
   内容1 varchar(200),
   内容2 varchar(200),
   内容3 varchar(200),
   内容4 varchar(200),
   内容5 varchar(200),
   内容6 varchar(200)   
   )
   
  if (@wardid='' ) --没有找到对应的病区代码
  begin
    select * from #电子一览表
    drop table #电子一览表
	return
  end   
  declare @todaynote varchar(1000)
  declare @wardname varchar(100) 
  declare @str varchar(1000),@str1 varchar(1000), @str2 varchar(1000), @str3 varchar(1000)
  declare @str4 varchar(1000), @str5 varchar(1000), @str6 varchar(1000)
  declare @oldps int
  declare @ps int
  declare @loop int
  
   select top 1 @wardname=a.wardname,@todaynote=b.tomorrownote 
   from t_ward a ,t_ward_work b
   where a.wardid=@wardid 
		and b.wardid=a.wardid  
   
   --将病区，病房，病床，病人信息插入到 临时表
   insert into #电子一览表(	
   病区代码 ,
   病区名称 ,
   内容
	)
   select @wardid,@wardname,@todaynote  
   set @ps = charindex(';',@todaynote)  
   print @ps
   --update t_ward_work set tomorrownote='明天早上9点，15床病人要做尿液检验;测试测试一下;今天天气还不错'
   --where wardid='1515F'
   set @oldps=1
   set @loop=1
   if @ps>0
   begin
       if (RIGHT(@todaynote,1)<>';')
         set @todaynote=@todaynote+';'       
	   while (@ps>0)
	   begin
	     print convert(varchar,@oldps)+' '+convert(varchar,@ps)
	     set @str=substring(@todaynote,@oldps,@ps-@oldps)
	     print @str
         if (@loop=1 )
			 set @str1=@str
		 else if (@loop=2) 
		     set @str2=@str
		 else if (@loop=3) 
		     set @str3=@str
		 else if (@loop=4) 
		     set @str4=@str
		 else if (@loop=5) 
		     set @str5=@str
		 else if (@loop=6) 
		     set @str6=@str		
		 set @oldps=@ps+1
		 set @ps=charindex(';',@todaynote,@oldps)  
		 set @loop=@loop+1  		     		     		     
	   end
	   update #电子一览表 set 内容1=@str1,内容2=@str2,内容3=@str3,内容4=@str4,内容5=@str5,内容6=@str6
   end
   else
   begin
     update #电子一览表 set 内容1=@todaynote
   end
    
   select * from #电子一览表
   drop table #电子一览表
   return
go

