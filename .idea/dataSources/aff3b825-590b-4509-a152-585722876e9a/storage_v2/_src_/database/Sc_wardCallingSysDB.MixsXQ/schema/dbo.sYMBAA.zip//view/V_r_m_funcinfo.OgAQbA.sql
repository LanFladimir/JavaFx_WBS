CREATE VIEW [dbo].[V_r_m_funcinfo]
AS
SELECT     dbo.t_sys_r_f_menu.autoid, dbo.t_sys_r_f_menu.roleid, dbo.t_sys_r_f_menu.menuid, dbo.t_sys_r_f_menu.funcid, dbo.t_sys_r_f_menu.creator, 
                      dbo.t_sys_r_f_menu.createtime, dbo.t_sys_r_f_menu.editor, dbo.t_sys_r_f_menu.modifytime, dbo.t_sys_func.funcname, dbo.t_sys_menu.menuname
FROM         dbo.t_sys_r_f_menu LEFT OUTER JOIN
                      dbo.t_sys_menu ON dbo.t_sys_r_f_menu.menuid = dbo.t_sys_menu.menuid LEFT OUTER JOIN
                      dbo.t_sys_func ON dbo.t_sys_r_f_menu.funcid = dbo.t_sys_func.funcid
go

