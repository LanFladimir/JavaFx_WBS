CREATE procedure [dbo].[getWardBedReport]                   
 @wardid varchar(20)           
-- getWardBedReport 1         
--@wardid 病区代码              
as                               
 select top 100000 r.roomid bfdm,
		r.roomname bfmc,
    r.alias bfbm,
    b.bedid bcdm,
    b.bedname bcmc,
    b.alias bcbm,
     case when b.status=0 then '空闲' 
				  when b.status=1 then '使用中' 
					else '维护中' end as zt
  from t_sickroom r,t_sickbed b 
	where r.roomid=b.roomid  and r.wardid=@wardid--and r.wardid=b.wardid
	order by r.roomid,b.bedid
go

