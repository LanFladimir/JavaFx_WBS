CREATE procedure [dbo].[GetConfigByIP]      
 @ip varchar(20)      
as    
declare @devicetype varchar(10)
declare @wardid varchar(10)
declare @zlpip varchar(18)
select @devicetype = DEVICETYPE,@wardid=WARDID from T_Device where IP=@ip
select @zlpip=ip from dbo.T_Device where wardid=@wardid AND DEVICETYPE='4'

select section,keyid,value,keyname from dbo.T_CONFIG where SECTION= @ip union
select section,keyid,value,keyname from dbo.T_CONFIG where SECTION= 'bedterminal-default' union
select section,keyid,value,keyname from dbo.T_CONFIG where SECTION= 'ward-'+@wardid UNION
select section,keyid,value,keyname from dbo.T_CONFIG where SECTION= 'system' UNION
select section,keyid,value,keyname from dbo.T_CONFIG where SECTION= @zlpip
go

