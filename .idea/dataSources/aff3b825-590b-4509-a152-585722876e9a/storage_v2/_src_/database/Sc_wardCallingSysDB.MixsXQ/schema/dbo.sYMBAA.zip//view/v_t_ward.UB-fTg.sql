create view [dbo].[v_t_ward]
as
select *,
(select username from t_sys_users u where u.userid=c.creator) createname,
(select username from t_sys_users u where u.userid=c.editor) editname
 from t_ward c
go

