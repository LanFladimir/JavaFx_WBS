create view [dbo].[v_t_inp_item]
as
SELECT   h.wardid,h.wardname,c.autoid, c.in_hospital_no, c.creator, c.createtime, c.editor, c.modifytime, c.itemcode,
                          (SELECT     username
                            FROM          dbo.t_sys_users AS u
                            WHERE      (userid = c.creator)) AS createname,
                          (SELECT     username
                            FROM          dbo.t_sys_users AS u
                            WHERE      (userid = c.editor)) AS editname, it.itemtype, it.itemname,
                            h.patient_name,h.bedid,h.bedname
FROM         dbo.t_inp_item AS c INNER JOIN
                      dbo.t_inp_itemtype AS it ON c.itemcode = it.autoid
                      left join v_t_inhospital h on c.in_hospital_no=h.in_hospital_no WHERE h.status='1'
go

