CREATE VIEW [dbo].[v_t_config]
AS
SELECT     autoid, section, keyid, keyname, value, creator, createtime, editor, modifytime, wardid,
                          (SELECT     wardname
                            FROM          dbo.t_ward AS w
                            WHERE      (wardid = c.wardid)) AS wardname,
                          (SELECT     username
                            FROM          dbo.t_sys_users AS u
                            WHERE      (userid = c.creator)) AS createname,
                          (SELECT     username
                            FROM          dbo.t_sys_users AS u
                            WHERE      (userid = c.editor)) AS editname
FROM         dbo.t_config AS c
go

