create view [dbo].[v_room_device_terminal]
as
SELECT dbo.t_sickroom.autoid, dbo.t_sickroom.roomid, dbo.t_sickroom.roomname, dbo.t_sickroom.deviceid, dbo.t_sickroom.alias, dbo.t_sickroom.createtime, dbo.t_sickroom.creator, 
dbo.t_sickroom.modifytime, dbo.t_sickroom.editor, dbo.t_sickroom.wardid, dbo.t_device.devicetype, dbo.t_device.devicename, dbo.t_device.ip, dbo.t_device.display_ui, dbo.t_terminal.terminalid, 
dbo.t_terminal.devicename AS terminalname, dbo.t_terminal.bedid, dbo.t_terminal.terminaltype
FROM         dbo.t_sickroom INNER JOIN
dbo.t_device ON dbo.t_sickroom.deviceid = dbo.t_device.deviceid INNER JOIN
dbo.t_terminal ON dbo.t_sickroom.roomid = dbo.t_terminal.roomid
go

