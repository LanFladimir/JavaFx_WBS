CREATE procedure [dbo].GetWardNurseCheck   
@wardid varchar(10),
@roomid varchar(10),
@begindate varchar(10),
@enddate varchar(10)       
as
if exists(select 1 from t_nursecheck_temp where wardid=@wardid and roomid=@roomid and convert(varchar(10),checktime,120) between @begindate and @enddate) 
begin
	delete from t_nursecheck_temp where wardid=@wardid and roomid=@roomid and convert(varchar(10),checktime,120) between @begindate and @enddate
end	
else begin	
	insert into t_nursecheck_temp(wardid,roomid,nurseid,timename,checktime)
	select wardid as bqdm,roomid as bfbm,nurseid as hsdm,
	(select timename from t_timeset t where t.timecode=n.timecode) as sdmc
	,checktime from t_nursecheck n
end
	select wardid as bqdm,roomid as bfbm,nurseid as hsdm,
	(select wardname from t_ward t where t.wardid=n.wardid)bqmc,
	(select roomname from t_sickroom t where t.roomid=n.roomid)bfmc,
	(select name from t_worker t where t.wardid=n.wardid and t.workid=n.nurseid and workertype='2')
	hsmc,
	timename as sdmc
	,checktime as qdsj from t_nursecheck_temp n
go

