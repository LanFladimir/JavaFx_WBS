create view [dbo].[v_t_notice]
as
select c.*, (SELECT     wardname
                            FROM          dbo.t_ward AS w
                            WHERE      (wardid = c.wardid)) AS wardname,
                          (SELECT     username
                            FROM          dbo.t_sys_users AS u
                            WHERE      (userid = c.creator)) AS createname,
                          (SELECT     username
                            FROM          dbo.t_sys_users AS u
                            WHERE      (userid = c.editor)) AS editname
 from t_notice c
go

