CREATE VIEW [dbo].[vw_T_InHospital]
AS
SELECT DISTINCT 
                      TOP (100) PERCENT dbo.T_InHospital.AUTOID, dbo.T_InHospital.WARDID, dbo.T_InHospital.ROOMID, dbo.T_InHospital.BEDID, dbo.T_InHospital.PATIENT_NAME, 
                      dbo.T_InHospital.PATIENT_CARD, dbo.T_InHospital.PATIENT_SEX, CASE patient_sex WHEN '0' THEN '女' WHEN '1' THEN '男' END AS patient_sex_name, 
                      dbo.T_InHospital.PATIENT_AGE, dbo.T_InHospital.PATIENT_GRADE, 
                      CASE patient_grade WHEN '1' THEN '一级护理' WHEN '2' THEN '二级护理' WHEN '3' THEN '三级护理' END AS patient_grade_name, 
                      dbo.T_InHospital.IN_HOSPITAL_TIME, dbo.T_InHospital.LEAVE_HOSPITAL_TIME, dbo.T_InHospital.PATIENT_DIAGNOSIS, dbo.T_InHospital.PATIENT_ALLERGY, 
                      dbo.T_InHospital.PATIENT_FOOD, dbo.T_InHospital.DOCTOR, dbo.T_InHospital.NURSE, dbo.T_InHospital.STATUS, 
                      CASE status WHEN '1' THEN '入院' WHEN '2' THEN '出院' END AS statusname, dbo.T_InHospital.CREATETIME, dbo.T_InHospital.CREATOR, 
                      dbo.T_InHospital.modifytime, dbo.T_InHospital.EDITOR, dbo.T_InHospital.IN_HOSPITAL_NO, dbo.T_WARD.WARDNAME, dbo.T_SickRoom.ROOMNAME
FROM         dbo.T_InHospital INNER JOIN
                      dbo.T_WARD ON dbo.T_InHospital.WARDID = dbo.T_WARD.WARDID INNER JOIN
                      dbo.T_SickRoom ON dbo.T_InHospital.WARDID = dbo.T_SickRoom.WARDID AND dbo.T_InHospital.ROOMID = dbo.T_SickRoom.ROOMID
ORDER BY dbo.T_InHospital.WARDID
go

