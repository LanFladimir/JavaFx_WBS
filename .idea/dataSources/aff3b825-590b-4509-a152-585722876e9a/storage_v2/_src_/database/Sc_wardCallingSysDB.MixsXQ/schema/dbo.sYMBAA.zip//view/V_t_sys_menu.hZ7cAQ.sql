create view [dbo].[V_t_sys_menu]
as
SELECT     TOP (100) PERCENT autoid, menuid, menuname, pmenuid, filename, ico, displayorder, isexpand, CASE isexpand WHEN '1' THEN '是' ELSE '否' END AS isexpandname, isuse, 
                      CASE isuse WHEN '1' THEN '是' ELSE '否' END AS isusename, isvisible, CASE isvisible WHEN '1' THEN '是' ELSE '否' END AS isvisiblename, creator,
                          (SELECT     username
                            FROM          dbo.t_sys_users AS u
                            WHERE      (userid = m.creator)) AS creatname, createtime, editor,
                          (SELECT     username
                            FROM          dbo.t_sys_users AS u
                            WHERE      (userid = m.editor)) AS editname, modifytime
FROM         dbo.t_sys_menu AS m
ORDER BY displayorder
go

