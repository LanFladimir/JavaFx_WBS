
CREATE VIEW [dbo].[v_t_inp_itemtype]
AS
SELECT     autoid, itemname, itemnote, creator, createtime, editor, modifytime, itemtype, 
                      CASE itemtype WHEN '1' THEN '药物过敏' WHEN '2' THEN '隔离方式' WHEN '3' THEN '饮食方式' WHEN '4' THEN '高危风险' WHEN '5' THEN '护理级别' WHEN '6' THEN '治疗方式' WHEN '7'
                       THEN '护理方式' END AS itemtypetext, his_itemcode,
                          (SELECT     username
                            FROM          dbo.t_sys_users AS u
                            WHERE      (userid = c.creator)) AS createname,
                          (SELECT     username
                            FROM          dbo.t_sys_users AS u
                            WHERE      (userid = c.editor)) AS editname, itemcode, color
FROM         dbo.t_inp_itemtype AS c

go

