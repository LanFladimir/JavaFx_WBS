CREATE VIEW [dbo].[V_AllMenu]
AS
SELECT     f.funcid, f.funcname, f.isuse AS fisuse, m.menuid, m.pmenuid, m.menuname, m.filename, m.ico, m.isexpand, m.isuse AS menuisuse, m.isvisible, m.displayorder
FROM         dbo.t_sys_menu AS m LEFT OUTER JOIN
                      dbo.t_sys_m_menufunc AS mf ON m.menuid = mf.menuid LEFT OUTER JOIN
                      dbo.t_sys_func AS f ON mf.funcid = f.funcid
go

