
create view [dbo].[V_t_sys_dept]
as
SELECT  d.*,
                          (SELECT     username
                            FROM          dbo.t_sys_users AS u
                            WHERE      (userid = d.creator))  creatname,
                          (SELECT     username
                            FROM          dbo.t_sys_users AS u
                            WHERE      (userid = d.editor)) AS editname,
                            CASE isuse WHEN '1' THEN '是' ELSE '否' END AS isusename
FROM         dbo.t_sys_dept AS d
go

