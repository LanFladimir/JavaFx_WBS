CREATE  procedure  [dbo].[getfee]  
  @ip varchar(20),
  @zdid int  
as   
  declare @wardid varchar(10)
  declare @bedid varchar(10)
  declare @zyh varchar(20)
  --获取病区代码      
  select @wardid=ISNULL(wardid,'') from t_device where ip=@ip and devicetype=1  
  --获取病床代码
    select @bedid=ISNULL(bedid,'') from t_terminal where terminaltype=1 and terminalid=@zdid 
	and bedid in (select bedid from t_sickbed where roomid in (select roomid from t_sickroom where wardid=@wardid)) 
  --获取住院号
    select @zyh=ISNULL(in_hospital_no,'') from t_inhospital where bedid=@bedid and status=1 
    
  select b.itemname,  convert(numeric(10,2),a.fee) fee from   (SELECT itemtype,sum(fee) fee FROM t_inp_fee where in_hospital_no=@zyh --and feedate>=convert(varchar(10),getdate(),121)
group by itemtype) a left join dbo.t_inp_itemtype b on a.itemtype = b.autoid and b.itemtype=9
order by b.itemname
go

