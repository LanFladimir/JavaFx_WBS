CREATE procedure  [dbo].[sp_过敏隔离信息_12F_15F]    
  @ip varchar(20)    
as     
  declare @wardid varchar(10)     
  select @wardid=wardid from t_device where ip=@ip and devicetype=5    
  set @wardid=ISNULL(@wardid,'')    
  create table #过敏隔离信息    
  (序号 int,  
   名称 varchar(100),    
   病床名称 varchar(200)    
   )    
  create table #电子一览表    
  (病区代码 varchar(10),    
   病区名称 varchar(30),    
   病房代码 varchar(10),    
   病房名称 varchar(30),      
   病床代码 varchar(10),    
   病床名称 varchar(30)            
   )    
       
  if (@wardid='' ) --没有找到对应的病区代码    
  begin    
    select '' 名称,'' 病床名称 where 1=2    
    drop table #电子一览表    
 return    
  end   
  declare @i int     
  set @i=1  
  declare @itemnote varchar(100)      
  declare @bednames varchar(500)   
  declare @mc varchar(30)   
  declare @itemnotecolor varchar(30)  
  declare @itemtype int  
  while (@i<21)  
  begin  
    insert into #电子一览表(     
    病区代码 ,    
    病区名称 ,    
    病房代码 ,    
    病房名称 ,       
    病床代码 ,    
    病床名称              
  )    
    select a.wardid,a.wardname,b.roomid,b.roomname,c.bedid,c.bedname    
    from t_ward a ,t_sickroom b,t_sickbed c,t_inhospital d,t_inp_item e    
    where a.wardid=@wardid     
   and b.wardid=a.wardid    
   and c.roomid=b.roomid    
   and d.bedid=c.bedid       
   and d.in_hospital_no=e.in_hospital_no     
   and d.status=1  
   and e.itemcode in (select autoid from t_inp_itemtype   
  where itemname in (select itemnote from t_inp_warditem where wardid=@wardid and seq=@i))     
   set @bednames=''    
   declare cursor1 cursor for             
   select 病床名称 from #电子一览表 order by 病床名称               
   open cursor1                            
   fetch next from cursor1 into @mc    
   while @@fetch_status=0               
   begin  
     set @mc=SUBSTRING(@mc,2,len(@mc)-1) 
     set @bednames = @bednames+ @mc+' '  --replicate('@@@',50)  -- ' '  
   fetch next from cursor1 into @mc    
   end     
   close cursor1                      
   deallocate cursor1       
   set @itemnote=''  
     
   select @itemnote=itemnote from t_inp_warditem where wardid=@wardid and seq=@i    
   set @itemtype=0
   select top 1 @itemnotecolor=color,@itemtype=itemtype from t_inp_itemtype where itemname=@itemnote   
   --set @itemnotecolor='#FF00FF'  
   set @itemtype=ISNULL(@itemtype,0)
   if @itemtype=1 --过敏  
   begin  
     if (CHARINDEX('+',@itemnote)>0)
       set @itemnote='<span style=''color:'+@itemnotecolor+'''>'+@itemnote+'</span>'
     else
       set @itemnote='<span style=''color:'+@itemnotecolor+'''>'+@itemnote+'</span>'+'<span style=''color:#FF0000''>'+'(+)'+'</span>'  
   end  
   else  
   begin  
     set @itemnote='<span style=''color:'+@itemnotecolor+'''>'+@itemnote+'</span>'  
   end  
   insert into #过敏隔离信息       
   select @i,@itemnote 名称,@bednames 病床名称    
   --select @i,@itemnote 名称,@bednames 病床名称    
   -- select @i,'&lt;span style=''color:#000000''&gt;'+@itemnote+'&lt;/span&gt;' 名称,@bednames 病床名称    
    truncate table #电子一览表    
    set @i=@i+1    
  end  
     
   select * from #过敏隔离信息     
   drop table #过敏隔离信息    
   return


go

