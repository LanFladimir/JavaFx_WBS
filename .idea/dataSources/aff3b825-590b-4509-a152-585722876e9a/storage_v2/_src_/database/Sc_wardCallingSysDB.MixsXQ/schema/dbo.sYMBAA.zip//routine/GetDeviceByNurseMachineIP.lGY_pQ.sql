
CREATE procedure [dbo].[GetDeviceByNurseMachineIP]    
--GetDeviceByNurseMachineIP '192.168.2.189'    
 @ip varchar(20)        
as        
 declare @cnt int        
 declare @wardid varchar(10)          
 declare @deviceid varchar(10)        
 declare @devicename varchar(100)   
 declare @devicealias varchar(100)       
  select @cnt=count(*) from t_device where devicetype=2 and ip=@ip      
 if @cnt>0       
 begin      
   --查询出此ip对应的病区代码，病房代码，设备代码，设备名称.      
   select @wardid=wardid,@deviceid=deviceid,@devicename=devicename       
   from  t_device where devicetype=2 and ip=@ip      

   select d.autoid,d.deviceid,devicename,d.alias,devicetype,ip,display_ui,d.wardid,w.wardname,w.alias wardalias,  
   d.roomid,r.roomname,r.alias roomalias from t_device d   
      left outer join t_ward w on d.wardid=w.wardid  
      left outer join t_sickroom r on d.wardid=r.wardid and d.roomid=r.roomid   
   where d.wardid=@wardid  and devicetype in (1,3,4,5)  
 end      
 else      
 begin      
   --返回空表      
   select d.autoid,d.deviceid,devicename,d.alias,devicetype,ip,display_ui,d.wardid,w.wardname,w.alias wardalias,  
     d.roomid,r.roomname,r.alias roomalias from t_device d   
      left outer join t_ward w on d.wardid=w.wardid  
      left outer join t_sickroom r on d.wardid=r.wardid and d.roomid=r.roomid   
   where 1<>1  
 end


go

