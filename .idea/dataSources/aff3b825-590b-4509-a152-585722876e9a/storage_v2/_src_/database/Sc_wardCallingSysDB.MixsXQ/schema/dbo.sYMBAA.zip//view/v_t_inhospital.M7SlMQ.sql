
CREATE VIEW [dbo].[v_t_inhospital]
AS
SELECT     autoid, wardid, roomid, in_hospital_no, bedid, patient_name, patient_card, patient_sex, CASE patient_sex WHEN '1' THEN '男' WHEN '0' THEN '女' END AS patient_sextext, patient_age, 
                      patient_grade,
                          (SELECT     itemcode
                            FROM          dbo.t_inp_itemtype AS it
                            WHERE      (itemtype = '5') AND (autoid = c.patient_grade)) AS itemcode,
                          (SELECT     itemname
                            FROM          dbo.t_inp_itemtype AS it
                            WHERE      (itemtype = '5') AND (autoid = c.patient_grade)) AS patient_gradetext, in_hospital_time, leave_hospital_time, patient_diagnosis, doctor, nurse, status, seriously, diagnosisdoctorid, 
                      diagnosisdoctorname, deptid, partition,
                          (SELECT     itemname
                            FROM          dbo.t_inp_itemtype AS it
                            WHERE      (itemtype = '2') AND (autoid = c.partition)) AS partitiontext, hisbedid, creator, createtime, editor, modifytime,
                          (SELECT     wardname
                            FROM          dbo.t_ward AS w
                            WHERE      (wardid = c.wardid)) AS wardname,
                          (SELECT     roomname
                            FROM          dbo.t_sickroom AS r
                            WHERE      (roomid = c.roomid)) AS roomname,
                          (SELECT     bedname
                            FROM          dbo.t_sickbed AS b
                            WHERE      (bedid = c.bedid)) AS bedname,
                          (SELECT     name
                            FROM          dbo.t_worker AS w
                            WHERE      (workid = c.doctor and wardid=c.wardid) AND (workertype = '1')) AS doctorname,
                          (SELECT     name
                            FROM          dbo.t_worker AS w
                            WHERE      (workid = c.nurse and wardid=c.wardid) AND (workertype = '2')) AS nursename, CASE status WHEN '1' THEN '住院中' WHEN '2' THEN '已出院' WHEN '3' THEN '已死亡' END AS statustext, 
                      CASE seriously WHEN '1' THEN '危重' ELSE '非危重' END AS seriouslytext,
                          (SELECT     username
                            FROM          dbo.t_sys_users AS u
                            WHERE      (userid = c.creator)) AS createname,
                          (SELECT     username
                            FROM          dbo.t_sys_users AS u
                            WHERE      (userid = c.editor)) AS editname, deadtime, modified, readstatus, readtime, feetype
FROM         dbo.t_inhospital AS c

go

