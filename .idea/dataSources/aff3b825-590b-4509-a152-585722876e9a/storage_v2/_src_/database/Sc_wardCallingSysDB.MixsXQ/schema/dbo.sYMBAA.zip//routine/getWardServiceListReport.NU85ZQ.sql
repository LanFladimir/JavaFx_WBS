create procedure [dbo].[getWardServiceListReport]           
 @wardid varchar(20),            
 @begindate varchar(10),    
 @enddate varchar(10)    
-- getWardServiceListReport 1,'2016-01-01','2016-01-31'    
--@wardid 病区代码    
--@begindate 报表开始日期      
--@enddate 报表结束日期    
as       
 declare @great int    
 declare @better int    
 declare @good int    
 declare @bad int    
 set @great=60    
 set @better=120    
 set @good=180    
 set @bad=300         
 declare @cnt int                   
 declare @deviceid varchar(10)            
 declare @devicename varchar(100)       
 declare @devicealias varchar(100)           
 --建立临时表.            
 create table #listreport           
 (序号 int IDENTITY (1,1),    
  呼叫时间 varchar(20),    
  呼叫者  varchar(30),    
  病区    varchar(100),    
  病房   varchar(100),    
  床位     varchar(100),      
  处理时间 varchar(20),    
  是否增援 varchar(2),  --是否    
  响应时间 varchar(20), --响应时间（秒)  1分钟10秒    
  响应情况 varchar(4), --优良合格差    
  紧急呼叫 varchar(4)  --是否紧急呼叫      
 )            
               
               
 select @cnt=count(*) from t_ward where wardid=@wardid     
 if @cnt>0             
 begin            
   --查询出此ip对应的病区代码，病房代码，设备代码，设备名称.    
    insert into #listreport(呼叫时间,呼叫者,病区,    
  病房,床位,处理时间,    
  是否增援,响应时间,响应情况,    
    紧急呼叫)                
    select convert(varchar(20),l.dialtime,120),isnull(h.patient_name,l.in_hospital_no),w.wardname,    
    r.roomname,b.bedname,convert(varchar(20),l.starttime,120),       
    case when l.status=2 then '是' else '否' end,
    case when l.STARTTIME IS null then '' when l.STARTTIME='1900-01-01' then ''
    else         
    convert(varchar,floor(datediff(s,l.dialtime,l.starttime) /60))+'分'+    
    convert(varchar,datediff(s,l.dialtime,l.starttime)-floor(datediff(s,l.dialtime,l.starttime) /60)*60)+'秒'
    end,    
    case when l.status=0 then '差'
         when l.STARTTIME IS null then '差' 
         when l.STARTTIME='1900-01-01' then '差'      
         when datediff(s,l.dialtime,l.starttime)<=@great then '优'    
         when datediff(s,l.dialtime,l.starttime)<=@better then '良'     
         when datediff(s,l.dialtime,l.starttime)<=@good then '合格'         
         else '差'        
    end,    
    case when l.type=2 then  '紧急' else '普通' end        
    from t_calllog l    
    left outer join  t_ward w on l.wardid=w.wardid    
    left outer join  t_sickroom r on l.wardid=r.wardid and l.roomid=r.roomid    
    left outer join t_sickbed b on  l.roomid=b.roomid  and l.bedid=b.bedid    
   left outer join t_inhospital h on l.in_hospital_no=h.in_hospital_no    
   where w.wardid=@wardid        
   and dialtime between @begindate and dateadd(d,1,@enddate)  
   order by dialtime     
   --更新病人信息            
   --更新医生信息，护士信息            
   --返回门口屏对应的信息            
   select 序号 xh,呼叫时间 hjsj,呼叫者 hjz,病区 bq,    
  病房 bf,床位 bc,处理时间 clsj,    
  是否增援 sfzy,响应时间 xysj,响应情况 xyqk,    
    紧急呼叫 jjhj from #listreport            
 end            
 else            
 begin            
   --返回空表            
   select 序号 xh,呼叫时间 hjsj,呼叫者 hjz,病区 bq,    
  病房 bf,床位 bc,处理时间 clsj,    
  是否增援 sfzy,响应时间 xysj,响应情况 xyqk,    
    紧急呼叫 jjhj  from #listreport            
 end            
--删除临时表            
 drop table #listreport
go

