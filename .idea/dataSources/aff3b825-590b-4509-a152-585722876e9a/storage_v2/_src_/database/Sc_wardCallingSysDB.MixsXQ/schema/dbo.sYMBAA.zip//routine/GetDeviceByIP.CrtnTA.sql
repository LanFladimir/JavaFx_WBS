--GetDeviceByIP '192.168.2.190'      
create procedure [dbo].[GetDeviceByIP]      
 @ip varchar(20)      
as      
SELECT a.devicetype,a.deviceid,a.devicename,a.ip,
a.wardid,a.roomid
FROM  T_device a LEFT JOIN  t_ward b ON a.WARDID=b.WARDID        
WHERE   a.wardid IN(select wardid from t_device where ip=@ip)


go

