CREATE VIEW [dbo].[vw_T_Notice]
AS
SELECT     dbo.T_Notice.*
FROM         dbo.T_Notice
go

