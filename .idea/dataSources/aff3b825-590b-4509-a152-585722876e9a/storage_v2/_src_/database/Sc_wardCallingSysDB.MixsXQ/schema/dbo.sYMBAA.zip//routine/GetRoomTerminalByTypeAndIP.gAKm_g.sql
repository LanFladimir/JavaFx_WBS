CREATE procedure [dbo].[GetRoomTerminalByTypeAndIP]        
--GetRoomTerminalByTypeAndIP '192.168.2.190',1  
--得到ip对应的卫浴分机信息
--@ip 设备ip  
--@type 设备类型 1-主机 2-护士分机 3-门口屏 4-走廊屏幕 5-电子一览表 ,6-护士站管理端    
 @ip varchar(20),           
 @type int  
as            
/*
SELECT a.autoid,a.terminalid,a.DEVICENAME terminalname,a.alias,a.wardid,b.wardname,a.roomid,c.roomname,a.status FROM  T_Terminal a LEFT JOIN  t_ward b ON a.WARDID=b.WARDID
LEFT JOIN T_SickRoom c ON a.WARDID = c.WARDID  AND a.ROOMID = c.ROOMID        
WHERE a.TERMINALTYPE =2 AND  a.wardid IN(select wardid from t_device where ip=@ip)
*/


SELECT a.autoid,a.terminalid,a.DEVICENAME terminalname,a.alias,b.wardid,b.wardname,a.roomid,b.roomname,a.status 
FROM  T_Terminal a 
LEFT JOIN (SELECT t_sickroom.*,t_ward.wardname FROM t_sickroom LEFT JOIN t_ward ON t_sickroom.wardid = t_ward.wardid   WHERE t_sickroom.wardid IN(select wardid from t_device where ip=@ip)) b

 ON a.ROOMID = b.ROOMID        
WHERE a.TERMINALTYPE =2
AND a.roomid in
(SELECT roomid FROM t_sickroom WHERE wardid IN (select wardid from t_device where ip=@ip))
go

