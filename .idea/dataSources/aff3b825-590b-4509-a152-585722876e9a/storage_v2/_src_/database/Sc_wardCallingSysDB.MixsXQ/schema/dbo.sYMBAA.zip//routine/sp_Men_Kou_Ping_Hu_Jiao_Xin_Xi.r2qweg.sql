  
-------------------------------------  
/*  
存储过程名称：[sp_门口屏呼叫信息]
功能：根据ip参数获取本病区的门口屏呼叫信息  .  
返回说明:  
有紧急呼叫时返回所有紧急呼叫信息;
无紧急呼叫时，返回所有普通呼叫信息;
否则返回空集
找到对应ip的电子一览表设置,返回这个病区的所有电子一览表呼叫信息  ,  
返回内容包括：  
  (病区代码 varchar(10),  
   病区名称 varchar(30),  
   病房代码 varchar(10),  
   病房名称 varchar(30),         
   病床代码 varchar(50),  
   病床名称 varchar(100), 
   名称信息	varchar(100),
   呼叫状态 varchar(50),
   底图 varchar(100),
   主键字段 varchar(20)   
   )  
示例：  

exec [sp_门口屏呼叫信息]  '192.168.55.131'  
select * from t_device  
select * from t_sickroom where wardid='1507F' 
select 
select *  from t_terminal where roomid='0701'

update t_terminal set bedid='070101' where bedid='150101'
 update t_terminal set callstatus=0,calltime=getdate() where roomid='0701' and terminaltype=2
 update t_te
 update t
*/  
-------------------------------------  
create  procedure  [dbo].[sp_门口屏呼叫信息]  
  @ip varchar(20)  
as   
  declare @wardid varchar(10)  
  declare @roomid varchar(10)    
  select @wardid=wardid,@roomid=roomid from t_device where ip=@ip and devicetype=3  
  set @wardid=ISNULL(@wardid,'')  
  set @roomid=ISNULL(@roomid,'')    
  create table #电子一览表  
  (病区代码 varchar(10),  
   病区名称 varchar(30),  
   病房代码 varchar(10),  
   病房名称 varchar(30),         
   病床代码 varchar(50),  
   病床名称 varchar(100), 
   名称信息	varchar(100),
   呼叫状态 varchar(50),
   底图 varchar(100),
   主键字段 varchar(20)           
   )  
     
  if (@wardid='' )  --没有找到对应的病区代码 
  begin  
    select * from #电子一览表  
    drop table #电子一览表  
 return  
  end     
   --将病区，病房，病床，病人信息插入到 临时表  
   insert into #电子一览表(   
   病区代码 ,  
   病区名称 ,  
   病房代码 ,  
   病房名称 ,         
   病床代码 ,  
   病床名称 , 
   名称信息	,
   呼叫状态 ,
   底图,
   主键字段              
 )  
   select d.wardid,d.wardname,c.roomid,c.roomname,'','',
	'房','紧急呼叫','紧急呼叫.png' ,c.roomid+CONVERT(varchar(8),t.calltime,108)
	 
   from t_terminal t , t_sickroom c,t_ward d  where t.roomid=c.roomid  and c.wardid=@wardid
	and d.wardid=@wardid
    and t.terminaltype=2 and t.callstatus=1 
    order by t.calltime
  
    --left outer join t_sickbed b on t.terminaltype=1 and t.bedid=b.bedid 
    -- and b.roomid in (select roomid from t_sickroom where wardid=@wardid)  
   if not exists(select 1 from #电子一览表)  --没有紧急呼叫，则查询是否有普通呼叫
   begin
	   insert into #电子一览表(   
	   病区代码 ,  
	   病区名称 ,  
	   病房代码 ,  
	   病房名称 ,         
	   病床代码 ,  
	   病床名称 , 
	   名称信息	,
	   呼叫状态 ,
	   底图,
	   主键字段              
	 )  
	   select d.wardid,d.wardname,'','',c.bedid,c.bedname,
		'床','呼叫','普通呼叫.png',c.roomid+CONVERT(varchar(8),t.calltime,108) 		   
	   from t_terminal t , t_sickbed c,t_ward d where t.bedid=c.bedid  
			and c.roomid in (select roomid from t_sickroom where wardid=@wardid)  
		    and d.wardid=@wardid
	   and t.terminaltype=1  and t.callstatus=1 
	    order by t.calltime   
     
   end
             
   select * from #电子一览表  
   drop table #电子一览表  
   return


go

