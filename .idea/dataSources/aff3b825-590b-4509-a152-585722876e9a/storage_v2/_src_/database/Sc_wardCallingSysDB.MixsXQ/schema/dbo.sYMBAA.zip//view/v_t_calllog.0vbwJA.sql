create view [dbo].[v_t_calllog]
as
SELECT  *,
(select wardname from t_ward w where w.wardid=c.wardid) as wardname,
(select roomname from t_sickroom r where r.roomid=c.roomid) as roomname,
(select devicename  from t_terminal t where t.terminalid=c.terminalid) as devicename, 
case direction when '1' then '分机呼出' when '2' then '护士分机呼出' end as directiontext,
case type when '1' then '普通' when '2' then '紧急' end as typetext,
case status when '0' then '未接通' when '1' then '接通' when '2' then '转移接通' end as statustext,
(select bedname from t_sickbed b where b.bedid=c.bedid) bedname,
(select username from t_sys_users u where u.userid=c.creator) createname,
(select username from t_sys_users u where u.userid=c.editor) editname
FROM dbo.t_calllog c
go

