-------------------------------------  
/*  
存储过程名称：getinpmessage  
功能：根据病区呼叫主机IP和床头分机地址获取护士留言信息.  
返回说明:   
  职责 varchar(20),  
  姓名 varchar(20)    
示例：  
exec getinpmessage '192.168.2.90',1  
*/  
-------------------------------------  
CREATE  procedure  [dbo].[getinpmessage]  
  @ip varchar(20),
  @zdid int  
as   
  declare @wardid varchar(10)
  declare @bedid varchar(10)
  declare @zyh varchar(20)
  --获取病区代码      
  select @wardid=ISNULL(wardid,'') from t_device where ip=@ip and devicetype=1  
  --获取病床代码
    select @bedid=ISNULL(bedid,'') from t_terminal where terminaltype=1 and terminalid=@zdid 
	and bedid in (select bedid from t_sickbed where roomid in (select roomid from t_sickroom where wardid=@wardid)) 
  --获取住院号
    select @zyh=ISNULL(in_hospital_no,'') from t_inhospital where bedid=@bedid and status=1 
    
    SELECT top 8 message FROM t_inp_message where in_hospital_no=@zyh and status=1
go

