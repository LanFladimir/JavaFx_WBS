
create view [dbo].[v_t_inp_out]
as
SELECT    h.wardid,c.autoid, c.in_hospital_no, c.outtime, c.status, c.creator, c.createtime, c.editor, c.modifytime, 
CASE c.status WHEN '1' THEN '有效' WHEN '0' THEN '无效' WHEN '2' THEN '已出院' END AS statustext,
                          (SELECT     username
                            FROM          dbo.t_sys_users AS u
                            WHERE      (userid = c.creator)) AS createname,
                          (SELECT     username
                            FROM          dbo.t_sys_users AS u
                            WHERE      (userid = c.editor)) AS editname,
                          (SELECT     patient_name
                            FROM          dbo.t_inhospital AS g
                            WHERE      (in_hospital_no = c.in_hospital_no)) AS patient_name
FROM         dbo.t_inp_out AS c left join v_t_inhospital h on c.in_hospital_no=h.in_hospital_no
go

