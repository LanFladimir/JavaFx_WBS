create PROCEDURE [dbo].[GetPatientAllInfo] 
	@zyh varchar(10)
AS
	create table #patitentallinfolist
    (
    in_hospital_no varchar(10),
    guide_name  varchar(4000),
    itemname varchar(8000),
    patient_gradetext varchar(200),
    message varchar(500),
    doctorname varchar(40),
    nursename varchar(40)
    )

   if (@zyh='' ) --没有找到对应的wardid
   begin
     select * from #patitentallinfolist
     drop table #patitentallinfolist
	 return
   end
	--将 住院号 插入到 临时表 中
    insert into #patitentallinfolist(in_hospital_no,patient_gradetext)
    select b.in_hospital_no,patient_gradetext from v_t_inhospital b where b.in_hospital_no=@zyh
    order by b.autoid
    --将 宣教名称 更新到 临时表 中
     update #patitentallinfolist set guide_name=d.guide_name
	 from #patitentallinfolist p ,(select b.in_hospital_no, 
	 stuff((select '、'+cast(a.guide_name as varchar)  from t_guide a, t_inp_guide b,#patitentallinfolist t
	 where a.autoid=b.guide_autoid and b.in_hospital_no=t.in_hospital_no
	 group by b.in_hospital_no,a.guide_name for xml path('')),1,1,'')   as guide_name
	 from t_guide a, t_inp_guide b,#patitentallinfolist t
	 where a.autoid=b.guide_autoid  
	 and b.in_hospital_no=t.in_hospital_no
	 group by b.in_hospital_no,a.guide_name) d
	 where p.in_hospital_no=d.in_hospital_no 
	 --将项目更新到临时表 中
     update #patitentallinfolist set itemname=d.itemname
	 from #patitentallinfolist p ,(select a.in_hospital_no, 
	 stuff((select '、'+cast(b.itemname as varchar)  from t_inp_item a, t_inp_itemtype b,#patitentallinfolist t
	 where a.itemcode=b.autoid and a.in_hospital_no=t.in_hospital_no
	 group by a.in_hospital_no,b.itemname,itemtype for xml path('')),1,1,'')   as itemname
	 from t_inp_item a, t_inp_itemtype b,#patitentallinfolist t
	 where a.itemcode=b.autoid   and a.in_hospital_no=t.in_hospital_no
	 group by a.in_hospital_no,b.itemname,itemtype) d
	 where p.in_hospital_no=d.in_hospital_no 
    --将 护士留言 更新到 临时表 中
    update #patitentallinfolist set message=a.message 
    from #patitentallinfolist p,(select message,in_hospital_no from t_inp_message a where status='1' and 
    a.autoid in (select MAX(autoid) from t_inp_message b where a.in_hospital_no=b.in_hospital_no
    and a.status=b.status)) a where a.in_hospital_no=p.in_hospital_no
    
    --将 医生名称 更新到 临时表 中
	update #patitentallinfolist set doctorname=d.name
	 from #patitentallinfolist p ,(select a.in_hospital_no, 
	 stuff((select '、'+cast(a.workername as varchar)  from v_t_r_worker a, v_t_inhospital b,#patitentallinfolist t
	 where a.wardid=b.wardid 
	 and a.roomid=b.roomid 
	 and b.in_hospital_no=t.in_hospital_no
	 and a.workertype='1'
	 group by b.in_hospital_no,a.workername for xml path('')),1,1,'')   as name
	 from t_inp_item a, t_inp_itemtype b,#patitentallinfolist t
	 where a.itemcode=b.autoid   and a.in_hospital_no=t.in_hospital_no
	 group by a.in_hospital_no,b.itemname,itemtype) d
	 where p.in_hospital_no=d.in_hospital_no 
    
    --将 护士名称 更新到 临时表 中
	 update #patitentallinfolist set nursename=d.name
	 from #patitentallinfolist p ,(select a.in_hospital_no, 
	 stuff((select '、'+cast(a.workername as varchar)  from v_t_r_worker a, v_t_inhospital b,#patitentallinfolist t
	 where a.wardid=b.wardid 
	 and a.roomid=b.roomid 
	 and b.in_hospital_no=t.in_hospital_no
	 and a.workertype='2'
	 group by b.in_hospital_no,a.workername for xml path('')),1,1,'')   as name
	 from t_inp_item a, t_inp_itemtype b,#patitentallinfolist t
	 where a.itemcode=b.autoid   and a.in_hospital_no=t.in_hospital_no
	 group by a.in_hospital_no,b.itemname,itemtype) d
	 where p.in_hospital_no=d.in_hospital_no 
	 select * from #patitentallinfolist
	drop table #patitentallinfolist
	return
go

