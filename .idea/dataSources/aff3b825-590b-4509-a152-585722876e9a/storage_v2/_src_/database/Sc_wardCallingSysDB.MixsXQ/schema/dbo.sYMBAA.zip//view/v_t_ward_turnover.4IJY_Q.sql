
create view [dbo].[v_t_ward_turnover]
as 
select *,(select wardname from t_ward w where w.wardid=c.wardid) as wardname,
(select wardname from t_ward w where w.wardid=c.fromwardid) as fromwardname,
(select wardname from t_ward w where w.wardid=c.towardid) as towardname,
(select bedname from t_sickbed b where b.bedid=c.tobedid) tobedname,
(select bedname from t_sickbed b where b.bedid=c.frombedid) frombedname,
(select username from t_sys_users u where u.userid=c.creator) createname,
(select username from t_sys_users u where u.userid=c.editor) editname,
(select h.patient_name from v_t_inhospital h where h.in_hospital_no=c.in_hospital_no)as patient_name
 from t_ward_turnover c
go

