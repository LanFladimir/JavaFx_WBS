/*WHERE     (dbo.t_sys_users.flag <> 0)*/
CREATE VIEW dbo.V_UserInfo
AS
SELECT     dbo.t_sys_r_userrole.roleid, dbo.t_sys_users.userid, dbo.t_sys_users.username, dbo.t_sys_users.actualname, dbo.t_sys_users.userpass, dbo.t_sys_users.status, 
                      CASE dbo.t_sys_users.status WHEN '0' THEN '正常' WHEN '1' THEN '挂起' END AS statustext, dbo.t_sys_users.deptid, dbo.t_sys_users.logincount, 
                      dbo.t_sys_users.multipleentry, dbo.t_sys_users.creator, dbo.t_sys_users.createtime, dbo.t_sys_users.editor,
                          (SELECT     username
                            FROM          dbo.t_sys_users AS u
                            WHERE      (userid = dbo.t_sys_users.creator)) AS createname,
                          (SELECT     username
                            FROM          dbo.t_sys_users AS u
                            WHERE      (userid = dbo.t_sys_users.editor)) AS editname, dbo.t_sys_users.modifytime, dbo.t_sys_users.waittime, dbo.t_sys_dept.deptname, 
                      dbo.t_sys_role.rolename, dbo.t_sys_r_userrole.autoid AS userroleid, dbo.t_sys_users.flag, dbo.t_sys_users.autoid
FROM         dbo.t_sys_role INNER JOIN
                      dbo.t_sys_r_userrole ON dbo.t_sys_role.roleid = dbo.t_sys_r_userrole.roleid RIGHT OUTER JOIN
                      dbo.t_sys_users LEFT OUTER JOIN
                      dbo.t_sys_dept ON dbo.t_sys_users.deptid = dbo.t_sys_dept.deptid ON dbo.t_sys_r_userrole.userid = dbo.t_sys_users.userid
go

