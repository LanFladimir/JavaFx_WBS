
-------------------------------------
/*
存储过程名称：sp_预约出院信息
功能：根据ip参数获取本病区的备注信息信息.
返回说明:
找到对应ip的电子一览表设置,返回这个病区的所有备注信息,
返回内容包括：
  (名称 ,
   病床名称
   )
示例：
exec sp_预约出院信息 '192.168.55.139'
select * from t_device 
select * from t_inhospital where in_hospital_no in (
select in_hospital_no from t_inp_out where outtime>'2017-06-01')
*/
-------------------------------------
CREATE procedure  [dbo].[sp_预约出院信息]
  @ip varchar(20)
as 
  declare @wardid varchar(10) 
  select @wardid=wardid from t_device where ip=@ip and devicetype=5
  set @wardid=ISNULL(@wardid,'')

  create table #电子一览表
  (病区代码 varchar(10),
   病区名称 varchar(30),
   病房代码 varchar(10),
   病房名称 varchar(30),  
   病床代码 varchar(10),
   病床名称 varchar(30),     
   出院日期 varchar(10),
   出院午别 varchar(2)          
   )
   
  if (@wardid='' ) --没有找到对应的病区代码
  begin
    select '' 名称,'' 病床名称 where 1=2
    drop table #电子一览表
	return
  end   
   --将病区，病房，病床，病人信息插入到 临时表
   insert into #电子一览表(	
   病区代码 ,
   病区名称 ,
   病房代码 ,
   病房名称 ,   
   病床代码 ,
   病床名称 ,
   出院日期 ,
   出院午别         
	)
   select a.wardid,a.wardname,b.roomid,b.roomname,c.bedid,c.bedname,
	CONVERT(varchar(5),outtime,110) as c1,
	case when DATEPART(HH,outtime)>12 then 'PM' else 'AM' end  as c2
   from t_ward a ,t_sickroom b,t_sickbed c,t_inhospital d,t_inp_out e
   where a.wardid=@wardid 
		and b.wardid=a.wardid
		and c.roomid=b.roomid
		and d.bedid=c.bedid	
		and d.in_hospital_no=e.in_hospital_no	
		--and d.status=1
		and e.outtime>=CONVERT(varchar(10),getdate()+1,120) 
   declare @bedids varchar(500)
   declare @bednames varchar(500)
   set @bedids=''
   set @bednames=''
   declare @mc varchar(30)
   declare @rq varchar(10)
   declare @wb varchar(10)
  declare cursor1 cursor for         
  select 病床名称,出院日期,出院午别 from #电子一览表 order by 病床名称           
  open cursor1                        
  fetch next from cursor1 into @mc,@rq,@wb
  while @@fetch_status=0           
  begin
    set @mc=SUBSTRING(@mc,2,len(@mc)-1)
    set @bednames = @bednames+ @mc+'('+@rq+@wb+')'+' '
  fetch next from cursor1 into @mc,@rq,@wb
  end 
  close cursor1                  
  deallocate cursor1    
   select '预约出院' 名称,@bednames 病床名称
   drop table #电子一览表
   return



go

