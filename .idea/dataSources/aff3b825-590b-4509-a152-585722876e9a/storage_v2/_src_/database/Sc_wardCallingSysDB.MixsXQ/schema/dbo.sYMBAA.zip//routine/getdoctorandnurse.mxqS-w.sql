CREATE  procedure  [dbo].[getdoctorandnurse]  
  @ip varchar(20),
  @zdid int  
as   
  declare @wardid varchar(10)
  declare @bedid varchar(10)
  --获取病区代码      
  select @wardid=ISNULL(wardid,'') from t_device where ip=@ip and devicetype=1  
  --获取病床代码
    select @bedid=ISNULL(bedid,'') from t_terminal where terminaltype=1 and terminalid=@zdid 
	and bedid in (select bedid from t_sickbed where roomid in (select roomid from t_sickroom where wardid=@wardid)) 
	
select 2 idx, '责任医生'+ replicate(' ',12-DATALENGTH('责任医生')) tx, b.name from T_inhospital a left join dbo.t_worker b on a.doctor= b.workid where a.bedid=@bedid AND a.status=1
union
select 3 idx, '责任护士'+ replicate(' ',12-DATALENGTH('责任护士')) tx, b.name from T_inhospital a left join dbo.t_worker b on a.nurse= b.workid where a.bedid=@bedid AND a.status=1
union
select 1 idx, '主治医生'+ replicate(' ',12-DATALENGTH('主治医生')) tx, b.name from T_inhospital a left join dbo.t_worker b on a.diagnosisdoctorid= b.workid where a.bedid=@bedid AND a.status=1
union
select 4 idx, '护士长' + replicate(' ',12-DATALENGTH('护士长')) tx, b.name from t_ward_work a left join dbo.t_worker b on a.headnurse= b.workid where a.wardid=@wardid
go

