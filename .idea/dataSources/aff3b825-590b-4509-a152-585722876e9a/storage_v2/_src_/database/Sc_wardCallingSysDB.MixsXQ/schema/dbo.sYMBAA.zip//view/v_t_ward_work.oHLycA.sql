
/****** Object:  View [dbo].[v_t_ward_work]    Script Date: 06/01/2017 14:18:30 ******/
CREATE VIEW [dbo].[v_t_ward_work]
AS
SELECT     autoid, wardid, doctor1, doctor2, doctor3, doctor4, nurse1, nurse2, nurse3, nurse4, workdoctor1, workdoctor2, workdoctor3, todaynote, tomorrownote, creator, createtime, editor, modifytime, 
                      headnurse, doctor5, doctor6, doctor7, doctor8, doctor9, doctor10, doctor11, doctor12, nurse5, nurse6,
                          (SELECT     wardname
                            FROM          dbo.t_ward AS w
                            WHERE      (wardid = c.wardid )) AS wardidname,
                          (SELECT     name
                            FROM          dbo.t_worker AS w
                            WHERE      (workid = c.doctor1 and wardid=c.wardid) AND (workertype = '1')) AS doctor1name,
                          (SELECT     name
                            FROM          dbo.t_worker AS w
                            WHERE      (workid = c.doctor2 and wardid=c.wardid) AND (workertype = '1')) AS doctor2name,
                          (SELECT     name
                            FROM          dbo.t_worker AS w
                            WHERE      (workid = c.doctor3 and wardid=c.wardid) AND (workertype = '1')) AS doctor3name,
                          (SELECT     name
                            FROM          dbo.t_worker AS w
                            WHERE      (workid = c.doctor4 and wardid=c.wardid) AND (workertype = '1')) AS doctor4name,
                          (SELECT     name
                            FROM          dbo.t_worker AS w
                            WHERE      (workid = c.doctor5 and wardid=c.wardid) AND (workertype = '1')) AS doctor5name,
                          (SELECT     name
                            FROM          dbo.t_worker AS w
                            WHERE      (workid = c.doctor6 and wardid=c.wardid) AND (workertype = '1')) AS doctor6name,
                          (SELECT     name
                            FROM          dbo.t_worker AS w
                            WHERE      (workid = c.doctor7 and wardid=c.wardid ) AND (workertype = '1')) AS doctor7name,
                          (SELECT     name
                            FROM          dbo.t_worker AS w
                            WHERE      (workid = c.doctor8 and wardid=c.wardid) AND (workertype = '1')) AS doctor8name,
                          (SELECT     name
                            FROM          dbo.t_worker AS w
                            WHERE      (workid = c.doctor9 and wardid=c.wardid) AND (workertype = '1')) AS doctor9name,
                          (SELECT     name
                            FROM          dbo.t_worker AS w
                            WHERE      (workid = c.doctor10 and wardid=c.wardid) AND (workertype = '1')) AS doctor10name,
                          (SELECT     name
                            FROM          dbo.t_worker AS w
                            WHERE      (workid = c.doctor11 and wardid=c.wardid) AND (workertype = '1')) AS doctor11name,
                          (SELECT     name
                            FROM          dbo.t_worker AS w
                            WHERE      (workid = c.doctor12 and wardid=c.wardid) AND (workertype = '1')) AS doctor12name,
                          (SELECT     name
                            FROM          dbo.t_worker AS w
                            WHERE      (workid = c.nurse1 and wardid=c.wardid) AND (workertype = '2')) AS nurse1name,
                          (SELECT     name
                            FROM          dbo.t_worker AS w
                            WHERE      (workid = c.nurse2 and wardid=c.wardid) AND (workertype = '2')) AS nurse2name,
                          (SELECT     name
                            FROM          dbo.t_worker AS w
                            WHERE      (workid = c.nurse3 and wardid=c.wardid) AND (workertype = '2')) AS nurse3name,
                          (SELECT     name
                            FROM          dbo.t_worker AS w
                            WHERE      (workid = c.nurse4 and wardid=c.wardid) AND (workertype = '2')) AS nurse4name,
                          (SELECT     name
                            FROM          dbo.t_worker AS w
                            WHERE      (workid = c.nurse5 and wardid=c.wardid) AND (workertype = '2')) AS nurse5name,
                          (SELECT     name
                            FROM          dbo.t_worker AS w
                            WHERE      (workid = c.nurse6 and wardid=c.wardid) AND (workertype = '2')) AS nurse6name,
                          (SELECT     name
                            FROM          dbo.t_worker AS w
                            WHERE      (workid = c.workdoctor1 and wardid=c.wardid) AND (workertype = '1')) AS workdoctor1name,
                          (SELECT     name
                            FROM          dbo.t_worker AS w
                            WHERE      (workid = c.workdoctor2 and wardid=c.wardid) AND (workertype = '1')) AS workdoctor2name,
                          (SELECT     name
                            FROM          dbo.t_worker AS w
                            WHERE      (workid = c.workdoctor3 and wardid=c.wardid) AND (workertype = '1')) AS workdoctor3name,
                          (SELECT     username
                            FROM          dbo.t_sys_users AS u
                            WHERE      (userid = c.creator)) AS createname,
                          (SELECT     username
                            FROM          dbo.t_sys_users AS u
                            WHERE      (userid = c.editor)) AS editname, doctortel
FROM         dbo.t_ward_work AS c


go

