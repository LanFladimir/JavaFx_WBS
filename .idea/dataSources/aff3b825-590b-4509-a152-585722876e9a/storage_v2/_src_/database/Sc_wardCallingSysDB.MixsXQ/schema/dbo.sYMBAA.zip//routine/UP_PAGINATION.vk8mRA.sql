CREATE PROCEDURE [dbo].[UP_PAGINATION]
	@TableName [varchar](25),
	@Column [varchar](25),
	@ViewField [varchar](4000) = '*',
	@sqlWhere [varchar](1500) = '',
	@OrderColumns [varchar](4000),
	@OrderType [varchar](4) = 'asc',
	@PageSize [int] = 10,
	@CurrentPage [int] = 1,
	@TotalPage [int] OUTPUT,
	@TotalCounts int output
WITH EXECUTE AS CALLER
AS
begin
	declare @sql varchar(4000)
	declare @sumRowSql nvarchar(4000)
	declare @ParmDefinition nvarchar(500)
	declare @TotalCount int  
if(@PageSize=0 and @CurrentPage=0) begin
	 select @sql=''
	 select @sumRowSql='',@ParmDefinition=''
	 select @TotalPage=0
     select @sql=N'select  * from ' + @TableName
     select @sql = @sql+ N' where 1=1 ' + @sqlWhere+N'  '
     select @sumRowSql = N'select @TotalCount = count(1) from ' + @TableName +N' where 1=1 ' + @sqlWhere --查询总记录数的SQL语句  
	 select @ParmDefinition = N'@TotalCount int output';   --定义查询SQL语句的参数类型     
	 exec sp_executesql @sumRowSql,@ParmDefinition,@TotalCount = @TotalCount output  --调用执行字符串的系统存储过程，并接收SQL语句中参数的值
	 select @TotalCounts = @TotalCount
end
if(LEN(@ViewField)>0) begin
	 select @TotalPage=0
	 select @sql=''
	 select @sql=N'select  ' + @ViewField + N' from ' + @TableName
	 select @sql = @sql+ N' where 1=1 ' + @sqlWhere+N'  '
end
if(LEN(@OrderColumns)>0 AND LEN(@OrderType)>0)begin
	select @sql = @sql+N' order by ' + @OrderColumns + N' '+@OrderType
end
if(@PageSize>0 and @CurrentPage>0 and LEN(@Column)>0)  BEGIN
	 --当返回的当前页大于总页数时
    if(@CurrentPage=0) 
    begin 
     set @CurrentPage=1
    end    
    if(@TotalPage<@CurrentPage) 
    begin 
     if(@TotalPage<>0)
     set @CurrentPage=@TotalPage
    end 
    --计算总页数  
    select @sql=''
    select @sumRowSql='',@ParmDefinition=''
	select @sumRowSql = N'select @TotalCount = count(1) from ' + @TableName +N' where 1=1 ' + @sqlWhere --查询总记录数的SQL语句  
	select @ParmDefinition = N'@TotalCount int output';   --定义查询SQL语句的参数类型     
	exec sp_executesql @sumRowSql,@ParmDefinition,@TotalCount = @TotalCount output  --调用执行字符串的系统存储过程，并接收SQL语句中参数的值
	select @TotalPage = (@PageSize+@TotalCount-1)/@PageSize; 
	select @TotalCounts = @TotalCount
	--计算分页数 
	if(LEN(@ViewField)>0)
	begin
		select @sql = N'select top '+ cast(@PageSize as varchar(6)) + ' ' + @ViewField + N' from ' + @TableName
	end
    else 
		select @sql = N'select top '+ cast(@PageSize as varchar(6)) + ' * from ' + @TableName
	select @sql = @sql+ N' where 1=1 ' + @sqlWhere+N' and ' + @Column + N' not in('
	select @sql = @sql+N' select top '+' ' +cast((@PageSize*(@CurrentPage-1)) as varchar(6))+' '
	select @sql = @sql+@Column+N' from '+@TableName+N' where 1=1 ' + @sqlWhere 
	select @sql = @sql+' order by ' + @OrderColumns + N' '+@OrderType
	select @sql = @sql+N')'
	if(LEN(@OrderColumns)>0 AND LEN(@OrderType)>0) begin
		select @sql = @sql+' order by ' + @OrderColumns + N' '+@OrderType
	end
end
	print @sql
	exec(@sql)
end
go

