CREATE procedure [dbo].[getWardTerminalReport]                   
 @wardid varchar(20)           
-- getWardTerminalReport 1         
--@wardid 病区代码              
as                               
 select top 100000 TERMINALID zddm,
	DEVICENAME zdmc,
	ALIAS zdbm,
	case when terminaltype=2 then '卫浴分机' else '床头分机' end lb,
    case when status=0 then '正常' when status=1 then '未检测到' when status=-1 then '故障' else '' end  zt from t_terminal
	--where wardid=1
	order by terminaltype,convert(int,terminalid)
go

