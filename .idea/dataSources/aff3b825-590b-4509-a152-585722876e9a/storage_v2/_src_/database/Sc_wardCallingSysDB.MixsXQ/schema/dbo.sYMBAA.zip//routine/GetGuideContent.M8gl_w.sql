CREATE procedure [dbo].[GetGuideContent]
@ip varchar(20),
@zdid int,
@flag int,
@itemindex int
as
  declare @wardid varchar(10)
  declare @bedid varchar(10)
  declare @zyh varchar(20)
  declare @guide_name varchar(50)
  declare @guide_content varchar(500)
  declare @rowno int
  --获取病区代码      
  select @wardid=ISNULL(wardid,'') from t_device where ip=@ip and devicetype=1  
  --获取病床代码
    select @bedid=ISNULL(bedid,'') from t_terminal where terminaltype=1 and terminalid=@zdid 
	and bedid in (select bedid from t_sickbed where roomid in (select roomid from t_sickroom where wardid=@wardid)) 
  --获取住院号
    select @zyh=ISNULL(in_hospital_no,'') from t_inhospital where bedid=@bedid and status=1   

    declare  mycursor cursor  for 
	select top 6 guide_name,guide_content from t_inp_guide  a left join t_guide b 
	on a.guide_autoid = b.autoid 
	where a.guide_autoid in (select autoid from t_guide where guide_type=@flag) 
	and IN_HOSPITAL_NO=@zyh order by guide_name
	open mycursor                          
    fetch next from mycursor into @guide_name,@guide_content
    set @rowno=1 
    while @@fetch_status=0             
    begin  
      if(@rowno=@itemindex) break;
      set @rowno = @rowno + 1
      fetch next from mycursor into @guide_name,@guide_content  
    end
    close mycursor                    
    deallocate mycursor 
    select @guide_name guide_name,@guide_content guide_content
go

