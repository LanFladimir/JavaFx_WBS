CREATE VIEW [dbo].[vw_T_Device]
AS
SELECT     d.AUTOID, d.DEVICETYPE, 
                      CASE WHEN DEVICETYPE = 1 THEN '主机' WHEN DEVICETYPE = 2 THEN '护士分机' WHEN DEVICETYPE = 3 THEN '门口屏' WHEN DEVICETYPE = 4 THEN '走廊屏幕'
                       WHEN DEVICETYPE = 5 THEN '电子一览表' END AS DEVICETYPENAME, d.DEVICEID, d.DEVICENAME, d.IP, d.DISPLAY_UI, d.WARDID, w.WARDNAME, d.ROOMID, 
                      e.ROOMNAME, d.CREATETIME, d.CREATOR, a.USERNAME AS CREATORNAME, d.modifytime, d.EDITOR, b.USERNAME AS EDITORNAME, d.ALIAS
FROM         dbo.T_Device AS d LEFT OUTER JOIN
                      dbo.T_WARD AS w ON d.WARDID = w.WARDID LEFT OUTER JOIN
                      dbo.t_sys_users AS a ON d.CREATOR = a.USERID LEFT OUTER JOIN
                      dbo.t_sys_users AS b ON d.EDITOR = b.USERID LEFT OUTER JOIN
                      dbo.T_SickRoom AS e ON d.ROOMID = e.ROOMID
go

