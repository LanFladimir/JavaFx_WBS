CREATE procedure SetNurseCheck(
@inp_no varchar(30),
@nurse_no varchar(30),
@ip varchar(30)
)
/*
SetNurseCheck 
设置护士巡视记录
参数 @inp_no 住院号
  @nurse_no 护士工号
根据住院号记录护士巡视时间和病房号
示例：SetNurseCheck '01255690','080838'  
*/
as
begin
  declare @wardid varchar(20)
  declare @roomid varchar(20)
  declare @timecode varchar(20)  
  if exists(
  select 1 from t_inhospital where in_hospital_no=@inp_no and status=1)
  begin
    select top 1 @wardid=wardid,@roomid=roomid from t_inhospital where in_hospital_no=@inp_no and status=1
    select @timecode=timecode from t_timeset
    where CONVERT(varchar(5),getdate(),108) between begintime and endtime
    
    insert into t_nursecheck(wardid,roomid,in_hospital_no,nurseid,timecode,checktime,modifytime,ip)
    select @wardid,@roomid,@inp_no,@nurse_no,@timecode,GETDATE(),GETDATE(),@ip        
  end  
end
go

