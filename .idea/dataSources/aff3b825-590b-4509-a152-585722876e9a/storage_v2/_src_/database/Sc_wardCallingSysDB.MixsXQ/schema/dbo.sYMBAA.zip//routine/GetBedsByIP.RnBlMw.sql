CREATE procedure [dbo].[GetBedsByIP]            
--GetBedByTypeAndIP '192.168.2.190',1      
--@ip 设备ip      
--@type 设备类型 1-主机 2-护士分机 3-门口屏 4-走廊屏幕 5-电子一览表 ,6-护士站管理端        
 @ip varchar(20)                  
as                
SELECT a.autoid,a.bedid,a.bedname,a.alias bedalias,a.status,  
c.wardid,b.wardname,b.alias wardalias,a.roomid,c.roomname,c.alias roomalias,  
patient_name,patient_card,patient_sex,patient_age, f.itemcode patient_grade   
,in_hospital_no,  
convert(varchar(10),in_hospital_time,121) in_hospital_time,patient_diagnosis,patient_allergy,patient_food,e.terminalid,e.status,  
g.itemname partition,  
e.autoid terminalautoid, case when d.modifytime is null then 
convert(varchar,a.modifytime,120) 
else
convert(varchar,d.modifytime,120) end modifytime  
FROM T_SickBed a  
LEFT JOIN T_SickRoom c ON  a.ROOMID = c.ROOMID  
LEFT JOIN T_WARD b ON c.WARDID = b.WARDID  
LEFT JOIN T_InHospital d ON  a.ROOMID = d.ROOMID AND a.BEDID = d.BEDID AND d.status=1  
LEFT JOIN T_Terminal e ON  a.ROOMID = e.ROOMID AND a.BEDID = e.BEDID   
LEFT JOIN  (select * from t_inp_itemtype where itemtype='5') f on d.patient_grade = f.autoid  
LEFT JOIN  (select * from t_inp_itemtype where itemtype='2') g on d.partition = g.autoid  
  
WHERE c.WARDID IN (SELECT wardid FROM T_Device WHERE ip='192.168.2.128')  
ORDER BY a.bedid  ---convert(INT,a.BEDID)
go

