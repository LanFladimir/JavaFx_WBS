create view v_t_inp_warditem
as
SELECT     autoid, wardid, seq, itemnote, creator, createtime, editor, modifytime,
                          (SELECT     wardname
                            FROM          dbo.t_ward AS w
                            WHERE      (wardid = c.wardid)) AS wardname,
                          (SELECT     username
                            FROM          dbo.t_sys_users AS u
                            WHERE      (userid = c.creator)) AS createname,
                          (SELECT     username
                            FROM          dbo.t_sys_users AS u
                            WHERE      (userid = c.editor)) AS editname
FROM         dbo.t_inp_warditem AS c
go

