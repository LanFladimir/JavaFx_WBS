
CREATE VIEW [dbo].[v_t_r_worker]
AS
select c.*,
 (SELECT     wardname
   FROM          dbo.t_ward AS w
   WHERE      (wardid = c.wardid)) AS wardname,
 (SELECT     roomname
   FROM          dbo.t_sickroom AS r
   WHERE      (roomid = c.roomid)) AS roomname,
    (SELECT       name
   FROM          dbo.t_worker AS r
   WHERE      (workid = c.workerid and wardid=c.wardid)) AS workername,
    (SELECT       name
   FROM          dbo.t_worker AS r
   WHERE      (workid = c.workerid1 and wardid=c.wardid)) AS worker1name,
    (SELECT       name
   FROM          dbo.t_worker AS r
   WHERE      (workid = c.workerid2 and wardid=c.wardid)) AS worker2name,
    (SELECT       name
   FROM          dbo.t_worker AS r
   WHERE      (workid = c.workerid3 and wardid=c.wardid)) AS worker3name,
   (SELECT        workertype
   FROM          dbo.t_worker AS r
   WHERE      (workid = c.workerid and wardid=c.wardid)) AS workertype,
    (SELECT        workertype
   FROM          dbo.t_worker AS r
   WHERE      (workid = c.workerid1 and wardid=c.wardid)) AS worker1type,
    (SELECT        workertype
   FROM          dbo.t_worker AS r
   WHERE      (workid = c.workerid2 and wardid=c.wardid)) AS worker2type,
    (SELECT        workertype
   FROM          dbo.t_worker AS r
   WHERE      (workid = c.workerid3 and wardid=c.wardid)) AS worker3type,
    (SELECT        CASE workertype WHEN '1' THEN '医生' WHEN '2' THEN '护士' END AS workertypetext
   FROM          dbo.t_worker AS r
WHERE      (workid = c.workerid and wardid=c.wardid)) AS workertypetext,
(SELECT        CASE workertype WHEN '1' THEN '医生' WHEN '2' THEN '护士' END AS workertypetext
FROM          dbo.t_worker AS r
WHERE      (workid = c.workerid1 and wardid=c.wardid)) AS worker1typetext,
(SELECT        CASE workertype WHEN '1' THEN '医生' WHEN '2' THEN '护士' END AS workertypetext
FROM          dbo.t_worker AS r
WHERE      (workid = c.workerid2 and wardid=c.wardid)) AS worker2typetext,
(SELECT        CASE workertype WHEN '1' THEN '医生' WHEN '2' THEN '护士' END AS worker3typetext
   FROM          dbo.t_worker AS r
WHERE      (workid = c.workerid3 and wardid=c.wardid)) AS worker3typetext,
 (SELECT     username
    FROM          dbo.t_sys_users AS u
    WHERE      (userid = c.creator)) AS createname,
  (SELECT     username
    FROM          dbo.t_sys_users AS u
    WHERE      (userid = c.editor)) AS editname
 from t_r_worker c
go

