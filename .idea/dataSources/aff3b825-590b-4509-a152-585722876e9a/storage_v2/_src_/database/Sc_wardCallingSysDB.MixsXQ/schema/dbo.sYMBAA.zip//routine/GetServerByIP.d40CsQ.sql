create  procedure [dbo].[GetServerByIP]      
 @ip varchar(20)      
as      
SELECT a.ip
FROM  T_device a LEFT JOIN  t_ward b ON a.WARDID=b.WARDID        
WHERE   a.wardid IN(select wardid from t_device where ip=@ip)  AND a.DEVICETYPE=1
go

