create procedure [dbo].[getWardServiceDayReport]                   
 @wardid varchar(20),                    
 @begindate varchar(10),            
 @enddate varchar(10),  
 @nozero int=0             
-- getWardServiceDayReport 1,'2016-03-01','2016-02-21'          
--@wardid 病区代码            
--@begindate 报表开始日期              
--@enddate 报表结束日期     
--@nozero 是否不显示为0的数据，1-不显示，0-显示 ,默认为0-显示       
as               
 declare @great int            
 declare @better int            
 declare @good int            
 declare @bad int            
 set @great=60            
 set @better=120            
 set @good=180            
 set @bad=300                 
 declare @cnt int                           
 declare @deviceid varchar(10)                    
 declare @devicename varchar(100)               
 declare @devicealias varchar(100)     
 declare @currentrq varchar(10)  
  
 --建立统计表  
 create table #dayreport(  
   rq  varchar(10),  
   sl int,  
   great int,  
   greatpecent varchar(10),  
   better int,  
   betterpecent varchar(10),  
   good int,  
   goodpecent varchar(10),  
   bad int,  
   badpecent varchar(10)  
 )  
  
                
 --建立临时表.                    
 create table #listreport                   
 (序号 int IDENTITY (1,1),            
  呼叫时间 varchar(20),            
  呼叫者  varchar(30),            
  病区    varchar(100),            
  病房   varchar(100),            
  床位     varchar(100),              
  处理时间 varchar(20),            
  是否增援 varchar(2),  --是否            
  响应时间 varchar(20), --响应时间（秒)  1分钟10秒            
  响应情况 varchar(4), --优良合格差            
  紧急呼叫 varchar(4)  --是否紧急呼叫              
 )                    
                       
                       
 select @cnt=count(*) from t_ward where wardid=@wardid             
 if @cnt>0                     
 begin     
    set @currentrq=@begindate  
    while (@currentrq<=@enddate)  
    begin  
       print '当前日期'+@currentrq  
       truncate table #listreport                 
   --查询出此ip对应的病区代码，病房代码，设备代码，设备名称.            
    insert into #listreport(呼叫时间,呼叫者,病区,            
  病房,床位,处理时间,            
  是否增援,响应时间,响应情况,            
    紧急呼叫)                        
    select convert(varchar(20),l.dialtime,120),isnull(h.patient_name,l.in_hospital_no),w.wardname,            
    r.roomname,b.bedname,convert(varchar(20),l.starttime,120),               
    case when l.status=2 then '是' else '否' end, 
    case when l.STARTTIME IS null then '' when l.STARTTIME='1900-01-01' then ''
    else                 
    convert(varchar,floor(datediff(s,l.dialtime,l.starttime) /60))+'分'+            
    convert(varchar,datediff(s,l.dialtime,l.starttime)-floor(datediff(s,l.dialtime,l.starttime) /60)*60)+'秒' 
    end,                
    case when l.status=0 then '差' 
         when l.STARTTIME IS null then '差' when l.STARTTIME='1900-01-01' then '差'                
         when datediff(s,l.dialtime,l.starttime)<=@great then '优'            
         when datediff(s,l.dialtime,l.starttime)<=@better then '良'             
         when datediff(s,l.dialtime,l.starttime)<=@good then '合格'                 
         else '差'                
    end,            
    case when l.type=2 then  '紧急' else '普通' end                
    from t_calllog l            
    left outer join  t_ward w on l.wardid=w.wardid            
    left outer join  t_sickroom r on l.wardid=r.wardid and l.roomid=r.roomid            
    left outer join t_sickbed b on l.roomid=b.roomid  and l.bedid=b.bedid            
   left outer join t_inhospital h on l.in_hospital_no=h.in_hospital_no            
   where w.wardid=@wardid                
   and dialtime between convert(date,@currentrq) and dateadd(d,1,convert(date,@currentrq))  
   order by dialtime             
   --更新病人信息                    
   --更新医生信息，护士信息                    
   --返回门口屏对应的信息                
   select IDENTITY(int,1,1) as  序号,响应情况,count(*)  数量,'        ' 比例 into #t from #listreport  group by 响应情况             
   select @cnt=count(*) from #listreport            
   update #t set 比例=convert(varchar,floor(数量*100/@cnt))+'%'            
           
   create table #rep  
   (xh varchar(10),xyqk varchar(4) ,sl int ,bl varchar(10))  
   insert into #rep(xh,xyqk,sl,bl)  
   values('1','优',0,'0%')  
   insert into #rep(xh,xyqk,sl,bl)  
   values('2','良',0,'0%')  
   insert into #rep(xh,xyqk,sl,bl)  
   values('3','合格',0,'0%')  
   insert into #rep(xh,xyqk,sl,bl)  
   values('4','差',0,'0%')  
   --insert into #rep(xh,xyqk,sl,bl)  
   --values('合 计','',0,'100%')        
     
   update #rep set sl=a.sl,bl=a.bl   
   from #rep r,(select convert(varchar,序号) xh,响应情况 xyqk,数量 sl,比例 bl from #t) a  
   where r.xyqk=a.xyqk   
  
   --update #rep set sl=@cnt where xh='合 计'  
  
     --select * from #rep  
     insert into #dayreport(rq,sl,great,greatpecent,better,betterpecent,good,goodpecent,bad,badpecent)  
     values(@currentrq,@cnt,0,'',0,'',0,'',0,'')  
  
     update #dayreport set great=a.sl,greatpecent=a.bl  
     from #dayreport r,#rep a   
     where r.rq=@currentrq and a.xh='1'  
  
     update #dayreport set better=a.sl,betterpecent=a.bl  
     from #dayreport r,#rep a   
     where r.rq=@currentrq and a.xh='2'  
  
     update #dayreport set good=a.sl,goodpecent=a.bl  
     from #dayreport r,#rep a   
     where r.rq=@currentrq and a.xh='3'  
  
     update #dayreport set bad=a.sl,badpecent=a.bl  
     from #dayreport r,#rep a   
     where r.rq=@currentrq and a.xh='4'  
  
       
     drop table #rep  
     drop table #t   
     set @currentrq=convert(varchar(10),dateadd(d,1,convert(date,@currentrq)),120)  
   end  
   select * from (  
   select top 1000 rq as xh,convert(varchar,datepart(d,rq))+'日' as rq,sl,great,greatpecent,better,betterpecent,good,goodpecent,bad,badpecent from #dayreport where (@nozero=1 and sl>0) or (@nozero=0)  
   order by xh  
   ) a  
   union  
   select '9999-01-01' as xh,'合 计' rq,sum(sl) sl,sum(great) great,(case when sum(sl)=0 then '100' else convert(varchar,sum(great)*100/sum(sl))  end) +'%' greatpecent,  
   sum(better) better,(case when sum(sl)=0 then '100' else convert(varchar,sum(better)*100/sum(sl))  end)+'%' betterpecent,  
      sum(good) good,(case when sum(sl)=0 then '100' else convert(varchar,sum(good)*100/sum(sl))  end)+'%' goodpecent,  
      sum(bad) bad,(case when sum(sl)=0 then '100' else convert(varchar,sum(bad)*100/sum(sl))  end)+'%' badpecent  
   from #dayreport  
  
   --select convert(varchar,序号) xh,响应情况 xyqk,数量 sl,比例 bl from #t            
   --union            
   --select '合 计' xh,'' xyqk,@cnt sl ,'100%' bl        
     
            
  
    -- select datepart(d,getdate())  
                 
 end                    
 else                    
 begin                    
   --返回空表                    
   select '0' xh,' ' xyqk,0 sl,'' bl       where 1<>1            
 end                    
--删除临时表                    
 drop table #listreport      
 drop table #dayreport
go

