create procedure [dbo].[sp_电子一览表_1]    
  @ip varchar(20)    
as     
  declare @wardid varchar(10)      
  select @wardid=wardid from t_device where ip=@ip and devicetype=5    
  set @wardid=ISNULL(@wardid,'')    
  create table #电子一览表    
  (住院号 varchar(10),  --住院号    
   姓名 varchar(30),    
   年龄 varchar(10),    
   性别 varchar(2),    
   诊断 varchar(100),    
   入院日期 varchar(10),    
   病区代码 varchar(10),    
   病区名称 varchar(30),    
   房间代码 varchar(10),    
   房间名称 varchar(30),    
   病床代码 varchar(10),    
   病床名称 varchar(30),    
   入出院状态图片 varchar(100),    
   护理级别 varchar(20),    
   护理级别图片 varchar(100),    
   科室代码 varchar(10),    
   科室名称 varchar(100),    
   患者信息底图 varchar(100)    
   )    
    
  if (@wardid='' ) --没有找到对应的病区代码    
  begin    
    select * from #电子一览表    
    drop table #电子一览表    
 return    
  end        
   --将病区，病房，病床，病人信息插入到 临时表    
   insert into #电子一览表(住院号,姓名,年龄,性别,诊断,入院日期,    
 病区代码,病区名称,房间代码,房间名称,病床代码,病床名称,    
 护理级别,科室代码,科室名称,入出院状态图片,患者信息底图)    
   select d.in_hospital_no,
    case when len( d.patient_name)>3 then substring (d.patient_name,1,1)+
          '☆☆'+substring ( d.patient_name,4,len( d.patient_name)-3)
        when len( d.patient_name)>2 then substring (d.patient_name,1,1)+
          '☆'+substring ( d.patient_name,3,len( d.patient_name)-2) 
          when len( d.patient_name)>1  then substring( d.patient_name,1,1)+
          '☆'+substring ( d.patient_name,2,len( d.patient_name)-1) 
          else  d.patient_name end as patient_name
     ,d.patient_age,case d.patient_sex when 1 then '男' when 0 then '女' end as patient_sex,d.patient_diagnosis,    
    CONVERT(varchar(10),d.in_hospital_time,120),    
    a.wardid,a.wardname,b.roomid,b.roomname,c.bedid,c.bedname,    
    i.itemname patient_grade,e.deptid,e.deptname,'正常.png','患者信息底图.png'    
   from t_ward a ,t_sickroom b,t_sickbed c     
   left outer join t_inhospital d on d.bedid=c.bedid    
   left outer join t_sys_dept e on e.deptid=d.deptid       
   left outer join t_inp_itemtype i on d.patient_grade=i.autoid and i.itemtype=5    
   where a.wardid=@wardid     
  and b.wardid=a.wardid    
        and c.roomid=b.roomid    
        and d.status=1  
   order by c.bedid  
        
   --更新病人的护理等级图片名称    
   update  #电子一览表 set 护理级别图片=护理级别+'.png'    
   --更新病人的入/出院标志    
   update #电子一览表 set 入出院状态图片='今出.png'    
   where 住院号 in (select in_hospital_no from t_inp_out     
  where outtime=CONVERT(varchar(10),getdate(),120))    
   --更新病人的入/出院标志    
   update #电子一览表 set 入出院状态图片='明出.png'    
   where 住院号 in (select in_hospital_no from t_inp_out     
  where outtime=CONVERT(varchar(10),getdate()+1,120))    
   --    
   update #电子一览表 set 入出院状态图片='新入.png'    
   where 住院号 in (select in_hospital_no from t_inhospital     
  where CONVERT(varchar(10),in_hospital_time,120)=CONVERT(varchar(10),getdate(),120))    
   --    
   select * from #电子一览表    
   drop table #电子一览表    
   return
go

