
CREATE PROC proc_电视机公告 
	@ip varchar(15)
AS
BEGIN
	SET NOCOUNT ON;
	select note from t_ward_note where wardid in(select wardid from t_device where ip=@ip) order by seq,autoid
END
go

