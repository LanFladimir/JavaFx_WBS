create view [dbo].[v_t_inp_guide]
as
SELECT  h.wardid, c.autoid, c.guide_autoid, c.in_hospital_no, c.order_index, c.creator, c.editor, c.createtime, c.modifytime,
                          (SELECT     username
                            FROM          dbo.t_sys_users AS u
                            WHERE      (userid = c.creator)) AS createname,
                          (SELECT     username
                            FROM          dbo.t_sys_users AS u
                            WHERE      (userid = c.editor)) AS editname,
                          (SELECT     guide_name
                            FROM          dbo.t_guide AS g
                            WHERE      (autoid = c.guide_autoid)) AS guide_autoidtext,
                          (SELECT     patient_name
                            FROM          dbo.t_inhospital AS g
                            WHERE      (in_hospital_no = c.in_hospital_no)) AS patient_name
FROM         dbo.t_inp_guide AS c left join v_t_inhospital h on c.in_hospital_no=h.in_hospital_no
go

