CREATE PROCEDURE getnoticebyip(@ip VARCHAR(20))
AS
SELECT noticecontent FROM  t_notice WHERE wardid IN (SELECT wardid FROM t_device WHERE ip=@ip)
AND convert(VARCHAR(20),begintime,121)<=convert(VARCHAR(20),getdate(),121) 
AND convert(VARCHAR(20),getdate(),121)<=convert(VARCHAR(20),endtime,121) ORDER BY seq
go

