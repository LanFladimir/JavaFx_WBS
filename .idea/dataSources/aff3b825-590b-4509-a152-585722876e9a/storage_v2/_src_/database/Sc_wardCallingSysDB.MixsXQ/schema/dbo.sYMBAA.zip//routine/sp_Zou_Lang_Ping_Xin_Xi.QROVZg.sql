  
-------------------------------------  
/*  
存储过程名称：sp_走廊屏信息  
功能：根据ip参数获取本病区的走廊屏信息.  
返回说明:  
找到对应ip的电子一览表设置,返回这个病区的所有走廊屏信息,  
返回内容包括：  
  (病区代码 varchar(10),  
   病区名称 varchar(30),
   病区别名 varchar(50)        
   )  
示例：  
exec sp_走廊屏信息  '192.168.2.93'  
*/  
-------------------------------------  
CREATE  procedure  [dbo].[sp_走廊屏信息]
  @ip varchar(20)  
as   
  declare @wardid varchar(10)  
  declare @roomid varchar(10)    
  select @wardid=wardid,@roomid=roomid from t_device where ip=@ip and devicetype=4  
  set @wardid=ISNULL(@wardid,'')  
  set @roomid=ISNULL(@roomid,'')    
  create table #电子一览表  
  (病区代码 varchar(10),  
   病区名称 varchar(50),
   病区别名 varchar(50)          
   )  
     
  if (@wardid='' )  --没有找到对应的病区代码 
  begin  
    select * from #电子一览表  
    drop table #电子一览表  
 return  
  end     
   --将病区，病房，病床，病人信息插入到 临时表  
   insert into #电子一览表(   
   病区代码 ,  
   病区名称 , 
   病区别名
 )  
   select d.wardid,d.wardname,d.alias
   from t_ward d
   where  wardid=@wardid	  
     
   select * from #电子一览表  
   drop table #电子一览表  
   return


go

