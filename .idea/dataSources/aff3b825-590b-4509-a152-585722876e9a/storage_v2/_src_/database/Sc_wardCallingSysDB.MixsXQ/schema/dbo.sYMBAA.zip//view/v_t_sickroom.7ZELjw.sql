create view [dbo].[v_t_sickroom]
as
select *,
(select wardname from t_ward w where w.wardid=c.wardid) as wardname,
(select d.devicename from t_device d where c.deviceid=d.deviceid) devicename,
(select username from t_sys_users u where u.userid=c.creator) createname,
(select username from t_sys_users u where u.userid=c.editor) editname
 from t_sickroom c
go

