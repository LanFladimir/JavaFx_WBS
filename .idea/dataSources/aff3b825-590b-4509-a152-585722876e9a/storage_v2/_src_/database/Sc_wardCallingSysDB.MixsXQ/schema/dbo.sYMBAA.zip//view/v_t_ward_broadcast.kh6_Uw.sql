create view [dbo].[v_t_ward_broadcast]
as 
select *,(select wardname from t_ward w where w.wardid=c.wardid) as wardname,
case status when '1' then '有效' when '0' then '无效' end as statustext,
(select username from t_sys_users u where u.userid=c.creator) createname,
(select username from t_sys_users u where u.userid=c.editor) editname
from t_ward_broadcast c
go

