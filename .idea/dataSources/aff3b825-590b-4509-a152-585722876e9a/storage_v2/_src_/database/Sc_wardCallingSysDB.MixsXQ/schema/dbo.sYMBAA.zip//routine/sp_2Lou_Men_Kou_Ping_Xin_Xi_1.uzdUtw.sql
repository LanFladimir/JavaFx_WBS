--sp_2楼门口屏信息 '192.168.57.11'
--select * from t_r_worker where roomid='1501'
CREATE  procedure  [dbo].[sp_2楼门口屏信息1]  
  @ip varchar(20)  
as   
  declare @wardid varchar(10)  
  declare @roomid varchar(10)    
  select @wardid=wardid,@roomid=roomid from t_device where ip=@ip and devicetype=3  
  set @wardid=ISNULL(@wardid,'')  
  set @roomid=ISNULL(@roomid,'')    
  
  create table #电子一览表  
  (病区代码 varchar(10),  
   病区名称 varchar(30),  
   病房代码 varchar(10),  
   病房名称 varchar(30),    
   护士长代码 varchar(10),  
   护士长姓名 varchar(20), 
   病床代码 varchar(100),  
   病床名称 varchar(200),       
   病床代码1 varchar(100),  
   病床名称1 varchar(200),       
   病床代码2 varchar(100),  
   病床名称2 varchar(200),       
   病床代码3 varchar(100),  
   病床名称3 varchar(200),       
   病床代码4 varchar(100),  
   病床名称4 varchar(200),       
   病床代码5 varchar(100),  
   病床名称5 varchar(200),       
   病床代码6 varchar(100),  
   病床名称6 varchar(200),       
   责任医生代码1 varchar(10),  
   责任医生姓名1 varchar(20),  
   责任医生代码2 varchar(10),  
   责任医生姓名2 varchar(20),  
   责任医生代码3 varchar(10),  
   责任医生姓名3 varchar(20),  
   责任医生代码4 varchar(10),  
   责任医生姓名4 varchar(20),  
   责任医生代码5 varchar(10),  
   责任医生姓名5 varchar(20),    
   责任医生代码6 varchar(10),  
   责任医生姓名6 varchar(20),         
   责任护士代码1 varchar(10),  
   责任护士姓名1 varchar(20),  
   责任护士代码2 varchar(10),  
   责任护士姓名2 varchar(20),     
   责任护士代码3 varchar(10),  
   责任护士姓名3 varchar(20),  
   责任护士代码4 varchar(10),  
   责任护士姓名4 varchar(20),     
   责任护士代码5 varchar(10),  
   责任护士姓名5 varchar(20),
   责任护士代码6 varchar(10),  
   责任护士姓名6 varchar(20),   
   呼叫状态 varchar(50)            
   )  
     
  if (@wardid='' ) or (@roomid='') --没有找到对应的病区代码和病房代码  
  begin  
    select * from #电子一览表  
    drop table #电子一览表  
 return  
  end     
   --将病区，病房，病床，病人信息插入到 临时表  
   insert into #电子一览表(   
   病区代码 ,  
   病区名称 ,  
   病房代码 ,  
   病房名称 --,     
   --病床代码 ,  
   --病床名称 ,       
   --责任医生代码1 ,  
   --责任医生姓名1 ,  
   --责任医生代码2 ,  
   --责任医生姓名2 ,  
   --责任医生代码3 ,  
   --责任医生姓名3 ,  
   --责任医生代码4 ,  
   --责任医生姓名4 ,  
   --责任医生代码5 ,  
   --责任医生姓名5 ,        
   --责任护士代码1 ,  
   --责任护士姓名1 ,  
   --责任护士代码2 ,  
   --责任护士姓名2 ,     
   --责任护士代码3 ,  
   --责任护士姓名3 ,  
   --责任护士代码4 ,  
   --责任护士姓名4 ,     
   --责任护士代码5 ,  
   --责任护士姓名5            
 )  
   select a.wardid,a.wardname,b.roomid,b.roomname      
   from t_ward a ,t_sickroom b  
   where a.wardid=@wardid   
  and b.wardid=a.wardid  
  and b.roomid=@roomid  
  
   declare @bedids varchar(100)  
   declare @bednames varchar(200)  
   declare @bednames_tail varchar(200)
   set @bedids=''  
   set @bednames=''  
   declare @id varchar(10)  
   declare @name varchar(30)  
  declare cursor1 cursor for           
  select bedid, case when substring(bedname,1,1)=0 then  
   right (left(bedname,LEN(bedname)+1),LEN(bedname)-1) else  bedname
	 end bedname  from t_sickbed where roomid=@roomid 
	 order by bedid             
  open cursor1                          
  fetch next from cursor1 into @id,@name    
  declare @loopi int  
  set @loopi=1  
  while @@fetch_status=0             
  begin  
    set @bedids = @bedids+@id+' '  
    IF(@loopi=1)
    --set @bednames = @bednames+@name+'  一  '  --
    set @bednames = @bednames+@name  --
    ELSE
    --set @bednames = @bednames+'  一  '+@name  --
    SET @bednames_tail = '  一  '+@name
    if (@loopi=1)  
     update  #电子一览表 set 病床代码1=@id,病床名称1=@name
     from #电子一览表 a   
    else if (@loopi=2)  
     update  #电子一览表 set 病床代码2=@id,病床名称2=@name
     from #电子一览表 a      
    else if (@loopi=3)  
     update  #电子一览表 set 病床代码3=@id,病床名称3=@name
     from #电子一览表 a 
    else if (@loopi=4)  
     update  #电子一览表 set 病床代码4=@id,病床名称4=@name
     from #电子一览表 a   
    else if (@loopi=5)     
     update  #电子一览表 set 病床代码5=@id,病床名称5=@name
     from #电子一览表 a          
    else if (@loopi=6)     
     update  #电子一览表 set 病床代码6=@id,病床名称6=@name
     from #电子一览表 a        
 --   if (@loopi=1)  
 --    update  #电子一览表 set 责任医生代码1=b.doctor,责任护士代码1=b.nurse
 --    from #电子一览表 a ,t_inhospital b   
 --    where a.病区代码=@wardid and b.bedid=@id   
 --   else if (@loopi=2)  
 --    update  #电子一览表 set 责任医生代码2=b.doctor,责任护士代码2=b.nurse  
 --    from #电子一览表 a ,t_inhospital b   
 --    where a.病区代码=@wardid and b.bedid=@id      
 --   else if (@loopi=3)  
 --    update  #电子一览表 set 责任医生代码3=b.doctor,责任护士代码3=b.nurse  
 --    from #电子一览表 a ,t_inhospital b   
 --    where a.病区代码=@wardid and b.bedid=@id   
 --   else if (@loopi=4)  
 --    update  #电子一览表 set 责任医生代码4=b.doctor,责任护士代码4=b.nurse 
 --    from #电子一览表 a ,t_inhospital b   
 --    where a.病区代码=@wardid and b.bedid=@id       
 --   else if (@loopi=5)     
 --    update  #电子一览表 set 责任医生代码5=b.doctor,责任护士代码5=b.nurse
	--from #电子一览表 a ,t_inhospital b   
 --    where a.病区代码=@wardid and b.bedid=@id           
 --   else if (@loopi=6)     
 --    update  #电子一览表 set 责任医生代码6=b.doctor,责任护士代码6=b.nurse
	--from #电子一览表 a ,t_inhospital b   
 --    where a.病区代码=@wardid and b.bedid=@id           
    set @loopi=@loopi+1       
  fetch next from cursor1 into @id,@name    
  end   
  close cursor1                    
  deallocate cursor1   
  
  SET @bednames = @bednames + @bednames_tail
   -------------------  
 --  select RANK() over( order by a.autoid) rk,workid,name 
	--into #tmp_doctor from t_r_worker a,t_worker b
 --  where a.workerid=b.workid and roomid=@roomid and workertype=1


 --  select RANK() over( order by a.autoid) rk,workid,name 
	--into #tmp_nurse from t_r_worker a,t_worker b
 --  where a.workerid=b.workid and roomid=@roomid and workertype=2

   --select * from #tmp_doctor
   --select * from #tmp_nurse
   
   update #电子一览表 set 病床代码=@bedids,病床名称=@bednames   
     
   update #电子一览表 set 责任医生代码1=b.workerid,  责任医生姓名1=c.name  
   from #电子一览表 a,t_r_worker b,t_worker c   where a.病房代码=b.roomid and b.workerid=c.workid
   
   
   update #电子一览表 set 责任医生代码2=b.workerid1,  责任医生姓名2=c.name  
   from #电子一览表 a,t_r_worker b,t_worker c   where a.病房代码=b.roomid and b.workerid1=c.workid

   update #电子一览表 set 责任护士代码1=b.workerid2,  责任护士姓名1=c.name  
   from #电子一览表 a,t_r_worker b,t_worker c   where a.病房代码=b.roomid and b.workerid2=c.workid
   
   update #电子一览表 set 责任护士代码2=b.workerid3,  责任护士姓名2=c.name  
   from #电子一览表 a,t_r_worker b,t_worker c   where a.病房代码=b.roomid and b.workerid3=c.workid
   
   ----where a.责任医生代码1=b.workid  
   --update #电子一览表 set 责任医生姓名2=b.name  
   --from #电子一览表 a,#tmp_doctor b   where b.rk=2
   ----where a.责任医生代码2=b.workid     
   --update #电子一览表 set 责任医生姓名3=b.name  
   --from #电子一览表 a,#tmp_doctor b   where b.rk=3
   ----where a.责任医生代码3=b.workid     
   --update #电子一览表 set 责任医生姓名4=b.name  
   --from #电子一览表 a,#tmp_doctor b   where b.rk=4
   ----where a.责任医生代码4=b.workid    
   --update #电子一览表 set 责任医生姓名5=b.name  
   --from #电子一览表 a,#tmp_doctor b   where b.rk=5
   ----where a.责任医生代码5=b.workid    
   --update #电子一览表 set 责任医生姓名6=b.name  
   --from #电子一览表 a,#tmp_doctor b   where b.rk=6
   ----where a.责任医生代码5=b.workid      
      
   --update #电子一览表 set 责任护士姓名1=b.name  
   --from #电子一览表 a,#tmp_nurse b   where b.rk=1
   ----where a.责任护士代码1=b.workid  
   --update #电子一览表 set 责任护士姓名2=b.name  
   --from #电子一览表 a,#tmp_nurse b   where b.rk=2
   ----where a.责任护士代码2=b.workid     
   --update #电子一览表 set 责任护士姓名3=b.name  
   --from #电子一览表 a,#tmp_nurse b   where b.rk=3 
   ----where a.责任护士代码3=b.workid     
   --update #电子一览表 set 责任护士姓名4=b.name  
   --from #电子一览表 a,#tmp_nurse b   where b.rk=4
   ----where a.责任护士代码4=b.workid    
   --update #电子一览表 set 责任护士姓名5=b.name  
   --from #电子一览表 a,#tmp_nurse b   where b.rk=5
   ----where a.责任护士代码5=b.workid        
   --update #电子一览表 set 责任护士姓名6=b.name  
   --from #电子一览表 a,#tmp_nurse b   where b.rk=6          
     
   update #电子一览表 set 护士长代码=b.workid,护士长姓名=b.name  
   from  t_ward_work a,t_worker b    
   where a.wardid=@wardid and a.headnurse=b.workid  
   
   --update #电子一览表 set 责任护士代码1=责任护士代码2,责任护士姓名1=责任护士姓名2
   --where isnull(责任护士代码1,'')=''
   --update #电子一览表 set 责任护士代码1=责任护士代码3,责任护士姓名1=责任护士姓名3
   --where isnull(责任护士代码1,'')=''   
   --update #电子一览表 set 责任护士代码1=责任护士代码4,责任护士姓名1=责任护士姓名4
   --where isnull(责任护士代码1,'')=''   
   --update #电子一览表 set 责任护士代码1=责任护士代码5,责任护士姓名1=责任护士姓名5
   --where isnull(责任护士代码1,'')=''   
   --update #电子一览表 set 责任护士代码1=责任护士代码6,责任护士姓名1=责任护士姓名6
   --where isnull(责任护士代码1,'')=''            

   --drop table #tmp_doctor
   --drop table #tmp_nurse
     
   declare @cnt int
   --是否有紧急呼叫--
   select @cnt=COUNT(*) from t_terminal where callstatus=1 and terminaltype=2 and roomid=@roomid
   if (@cnt>0)--有，则将呼叫状态改为紧急呼叫
      update  #电子一览表 set 呼叫状态='紧急呼叫' 
   else --无，则查询是否有床头分机呼叫
   begin
      --找出床头分机呼叫信息
      set @bednames=''      
	  declare cursor1 cursor for           
	  select a.bedid,a.bedname from t_sickbed a ,t_terminal b 
		where a.bedid=b.bedid and a.roomid=b.roomid 
			and callstatus=1 and terminaltype=1 and a.roomid=@roomid         
	  open cursor1                          
	  fetch next from cursor1 into @id,@name    
	  set @loopi=1  
	  while @@fetch_status=0             
	  begin  
		set @bedids = @bedids+@id+' '  
		set @bednames = @bednames+ @name+' '         
		set @loopi=@loopi+1  
	  fetch next from cursor1 into @id,@name    
	  end   
	  close cursor1                    
	  deallocate cursor1 
	  if (@bednames<>'') --如果有床头分机呼叫，则将呼叫状态改为几床呼叫。
	  begin
		update  #电子一览表 set 呼叫状态=@bednames+'呼叫'
	  end
   end   
     
   select * from #电子一览表  
   drop table #电子一览表  
   return
go

