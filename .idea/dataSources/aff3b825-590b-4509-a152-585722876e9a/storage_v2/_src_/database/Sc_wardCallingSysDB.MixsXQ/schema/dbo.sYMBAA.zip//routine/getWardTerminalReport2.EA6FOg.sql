CREATE procedure [dbo].[getWardTerminalReport2]                     
 @wardid varchar(20)               
-- getWardTerminalReport2 1             
--@wardid 病区代码                  
as          
 create table #terminalreport                   
 (病房代码  varchar(10),              
  病房名称  varchar(50),              
  病房别名  varchar(50),              
  终端代码1 varchar(10),              
  终端名称1 varchar(50),                
  终端别名1 varchar(50),              
  终端类别1 varchar(10),  
  终端状态1 varchar(10),  
  终端代码2 varchar(10),              
  终端名称2 varchar(50),  
  终端别名2 varchar(50),  
  终端类别2 varchar(10),  
  终端状态2 varchar(10),  
  终端代码3 varchar(10),              
  终端名称3 varchar(50),                
  终端别名3 varchar(50),              
  终端类别3 varchar(10),  
  终端状态3 varchar(10),  
  终端代码4 varchar(10),              
  终端名称4 varchar(50),                
  终端别名4 varchar(50),              
  终端类别4 varchar(10),  
  终端状态4 varchar(10),  
  终端代码5 varchar(10),              
  终端名称5 varchar(50),                
  终端别名5 varchar(50),              
  终端类别5 varchar(10),  
  终端状态5 varchar(10),  
  终端代码6 varchar(10),              
  终端名称6 varchar(50),                
  终端别名6 varchar(50),              
  终端类别6 varchar(10),  
  终端状态6 varchar(10),  
  终端代码7 varchar(10),              
  终端名称7 varchar(50),                
  终端别名7 varchar(50),              
  终端类别7 varchar(10),  
  终端状态7 varchar(10),  
  终端代码8 varchar(10),              
  终端名称8 varchar(50),                
  终端别名8 varchar(50),              
  终端类别8 varchar(10),  
  终端状态8 varchar(10)        
 )         
        
 insert into #terminalreport(病房代码,病房名称,病房别名)   
 select roomid,roomname,alias from t_sickroom where wardid=@wardid  
  
/*  
  create #terminal                  
 (病房代码  varchar(10),              
  病房名称  varchar(50),              
  病房别名  varchar(50),   
  序号  int,             
  终端代码1 varchar(10),              
  终端名称1 varchar(50),                
  终端别名1 varchar(50),              
  终端类别1 varchar(10),  
  终端状态1 varchar(10)  
  )  
  
  
  insert into #terminal(病房代码  varchar(10),              
  病房名称  varchar(50),              
  病房别名  varchar(50),              
  终端代码1 varchar(10),              
  终端名称1 varchar(50),                
  终端别名1 varchar(50),              
  终端类别1 varchar(10),  
  终端状态1 varchar(10)  
  select r.roomid,r.roomname,r.alias,t.TERMINALID,t.DEVICENAME,t.ALIAS,   
   case when terminaltype=2 then '卫浴分机' else '床头分机' end zdlb,    
  case when status=0 then '正常' when status=1 then '未检测到' when status=-1 then '故障' else '' end  zdzt    
  from t_sickroom r,t_terminal t where r.wardid=1 and r.roomid=t.roomid and r.wardid=t.wardid  
  order by   
 */   
    
 update #terminalreport set 终端代码1=a.zddm,终端名称1=a.zdmc,终端别名1=a.zdbm,终端类别1=a.zdlb,终端状态1=a.zdzt  
 from #terminalreport r,(select top 10000 roomid,TERMINALID zddm,    
 DEVICENAME zdmc,    
 ALIAS zdbm,    
 case when terminaltype=2 then '卫浴分机' else '床头分机' end zdlb,    
  case when status=0 then '正常' when status=1 then '未检测到' when status=-1 then '故障' else '' end  zdzt from t_terminal    
 --where wardid=@wardid   
  order by roomid,terminaltype,convert(int,terminalid)) as a  
where  r.病房代码=a.roomid   
  
 update #terminalreport set 终端代码2=a.zddm,终端名称2=a.zdmc,终端别名2=a.zdbm,终端类别2=a.zdlb,终端状态2=a.zdzt  
 from #terminalreport r,(select top 10000 roomid,TERMINALID zddm,    
 DEVICENAME zdmc,    
 ALIAS zdbm,    
 case when terminaltype=2 then '卫浴分机' else '床头分机' end zdlb,    
  case when status=0 then '正常' when status=1 then '未检测到' when status=-1 then '故障' else '' end  zdzt from t_terminal  t  
 where --wardid=@wardid  and 
		roomid+'-'+convert(varchar,terminaltype)+'-'+terminalid not in 
		(select top 1 roomid+'-'+convert(varchar,terminaltype)+'-'+terminalid from t_terminal 
		where roomid=t.roomid --and wardid=t.wardid
    group by roomid,terminaltype,terminalid--wardid,
    order by roomid,terminaltype,convert(int,terminalid) )--wardid, 
  order by roomid,terminaltype,convert(int,terminalid)) as a  
where  r.病房代码=a.roomid   


 update #terminalreport set 终端代码3=a.zddm,终端名称3=a.zdmc,终端别名3=a.zdbm,终端类别3=a.zdlb,终端状态3=a.zdzt  
 from #terminalreport r,(select top 10000 roomid,TERMINALID zddm,    
 DEVICENAME zdmc,    
 ALIAS zdbm,    
 case when terminaltype=2 then '卫浴分机' else '床头分机' end zdlb,    
  case when status=0 then '正常' when status=1 then '未检测到' when status=-1 then '故障' else '' end  zdzt from t_terminal  t  
 where --wardid=@wardid  and 
		roomid+'-'+convert(varchar,terminaltype)+'-'+terminalid not in 
		(select top 2 roomid+'-'+convert(varchar,terminaltype)+'-'+terminalid from t_terminal 
		where roomid=t.roomid --and wardid=t.wardid
    group by roomid,terminaltype,terminalid--wardid,
    order by roomid,terminaltype,convert(int,terminalid))--wardid, 
  order by roomid,terminaltype,convert(int,terminalid)) as a  
where  r.病房代码=a.roomid   


 update #terminalreport set 终端代码4=a.zddm,终端名称4=a.zdmc,终端别名4=a.zdbm,终端类别4=a.zdlb,终端状态4=a.zdzt  
 from #terminalreport r,(select top 10000 roomid,TERMINALID zddm,    
 DEVICENAME zdmc,    
 ALIAS zdbm,    
 case when terminaltype=2 then '卫浴分机' else '床头分机' end zdlb,    
  case when status=0 then '正常' when status=1 then '未检测到' when status=-1 then '故障' else '' end  zdzt from t_terminal  t  
 where --wardid=@wardid  and 
		roomid+'-'+convert(varchar,terminaltype)+'-'+terminalid not in 
		(select top 3 roomid+'-'+convert(varchar,terminaltype)+'-'+terminalid from t_terminal 
		where roomid=t.roomid --and wardid=t.wardid
    group by roomid,terminaltype,terminalid--wardid,
    order by roomid,terminaltype,convert(int,terminalid)) --wardid,
  order by roomid,terminaltype,convert(int,terminalid)) as a  
where  r.病房代码=a.roomid   


 update #terminalreport set 终端代码5=a.zddm,终端名称5=a.zdmc,终端别名5=a.zdbm,终端类别5=a.zdlb,终端状态5=a.zdzt  
 from #terminalreport r,(select top 10000 roomid,TERMINALID zddm,    
 DEVICENAME zdmc,    
 ALIAS zdbm,    
 case when terminaltype=2 then '卫浴分机' else '床头分机' end zdlb,    
  case when status=0 then '正常' when status=1 then '未检测到' when status=-1 then '故障' else '' end  zdzt from t_terminal  t  
 where --wardid=@wardid  and 
		roomid+'-'+convert(varchar,terminaltype)+'-'+terminalid not in 
		(select top 4 roomid+'-'+convert(varchar,terminaltype)+'-'+terminalid from t_terminal 
		where roomid=t.roomid --and wardid=t.wardid
    group by roomid,terminaltype,terminalid--wardid,
    order by roomid,terminaltype,convert(int,terminalid)) --wardid,
  order by roomid,terminaltype,convert(int,terminalid)) as a  
where  r.病房代码=a.roomid   

 update #terminalreport set 终端代码6=a.zddm,终端名称6=a.zdmc,终端别名6=a.zdbm,终端类别6=a.zdlb,终端状态6=a.zdzt  
 from #terminalreport r,(select top 10000 roomid,TERMINALID zddm,    
 DEVICENAME zdmc,    
 ALIAS zdbm,    
 case when terminaltype=2 then '卫浴分机' else '床头分机' end zdlb,    
  case when status=0 then '正常' when status=1 then '未检测到' when status=-1 then '故障' else '' end  zdzt from t_terminal  t  
 where --wardid=@wardid  and 
		roomid+'-'+convert(varchar,terminaltype)+'-'+terminalid not in 
		(select top 5 roomid+'-'+convert(varchar,terminaltype)+'-'+terminalid from t_terminal 
		where roomid=t.roomid --and wardid=t.wardid
    group by roomid,terminaltype,terminalid--wardid,
    order by roomid,terminaltype,convert(int,terminalid)) --wardid,
  order by roomid,terminaltype,convert(int,terminalid)) as a  
where  r.病房代码=a.roomid   

 update #terminalreport set 终端代码7=a.zddm,终端名称7=a.zdmc,终端别名7=a.zdbm,终端类别7=a.zdlb,终端状态7=a.zdzt  
 from #terminalreport r,(select top 10000 roomid,TERMINALID zddm,    
 DEVICENAME zdmc,    
 ALIAS zdbm,    
 case when terminaltype=2 then '卫浴分机' else '床头分机' end zdlb,    
  case when status=0 then '正常' when status=1 then '未检测到' when status=-1 then '故障' else '' end  zdzt from t_terminal  t  
 where --wardid=@wardid  and 
		roomid+'-'+convert(varchar,terminaltype)+'-'+terminalid not in 
		(select top 6 roomid+'-'+convert(varchar,terminaltype)+'-'+terminalid from t_terminal 
		where roomid=t.roomid --and wardid=t.wardid
    group by roomid,terminaltype,terminalid-- wardid,
    order by roomid,terminaltype,convert(int,terminalid)) --wardid,
  order by roomid,terminaltype,convert(int,terminalid)) as a  
where  r.病房代码=a.roomid   

 update #terminalreport set 终端代码8=a.zddm,终端名称8=a.zdmc,终端别名8=a.zdbm,终端类别8=a.zdlb,终端状态8=a.zdzt  
 from #terminalreport r,(select top 10000 roomid,TERMINALID zddm,    
 DEVICENAME zdmc,    
 ALIAS zdbm,    
 case when terminaltype=2 then '卫浴分机' else '床头分机' end zdlb,    
  case when status=0 then '正常' when status=1 then '未检测到' when status=-1 then '故障' else '' end  zdzt from t_terminal  t  
 where --wardid=@wardid  and 
		roomid+'-'+convert(varchar,terminaltype)+'-'+terminalid not in 
		(select top 7 roomid+'-'+convert(varchar,terminaltype)+'-'+terminalid from t_terminal 
		where roomid=t.roomid --and wardid=t.wardid
    group by roomid,terminaltype,terminalid--wardid,
    order by roomid,terminaltype,convert(int,terminalid)) --wardid,
  order by roomid,terminaltype,convert(int,terminalid)) as a  
where  r.病房代码=a.roomid   
--select * from t_terminal

 select 病房代码  bfdm,              
  病房名称  bfmc,              
  病房别名  bfbm,              
  终端代码1 zddm1,              
  终端名称1 zdmc1,                
  终端别名1 zdbm1,              
  终端类别1 zdlb1,  
  终端状态1 zdzt1,  
  终端代码2 zddm2,              
  终端名称2 zdmc2,  
  终端别名2 zdbm2,  
  终端类别2 zdlb2,  
  终端状态2 zdzt2,  
  终端代码3 zddm3,              
  终端名称3 zdmc3,                
  终端别名3 zdbm3,              
  终端类别3 zdlb3,  
  终端状态3 zdzt3,  
  终端代码4 zddm4,              
  终端名称4 zdmc4,                
  终端别名4 zdbm4,              
  终端类别4 zdzt4,  
  终端代码5 zddm5,              
  终端名称5 zdmc5,                
  终端别名5 zdbm5,              
  终端类别5 zdzt5, 
  终端代码6 zddm6,              
  终端名称6 zdmc6,                
  终端别名6 zdbm6,              
  终端类别6 zdzt6,  
  终端代码7 zddm7,              
  终端名称7 zdmc7,                
  终端别名7 zdbm7,              
  终端类别7 zdzt7, 
  终端代码8 zddm8,              
  终端名称8 zdmc8,                
  终端别名8 zdbm8,              
  终端类别8 zdzt8      from #terminalreport  
  
drop table #terminalreport
go

